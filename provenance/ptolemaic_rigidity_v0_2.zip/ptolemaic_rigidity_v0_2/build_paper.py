#!/usr/bin/env python3
"""Build the paper without mutating the archived source tree."""
import argparse, pathlib, shutil, subprocess

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--output',required=True,type=pathlib.Path)
    args=ap.parse_args(); root=pathlib.Path(__file__).resolve().parent
    out=args.output.resolve()
    if root==out or root in out.parents:raise SystemExit('Use an output directory outside the archive.')
    out.mkdir(parents=True,exist_ok=True)
    if not shutil.which('pdflatex'):raise SystemExit('pdflatex is required.')
    for i in range(3):
        run=subprocess.run(['pdflatex','-interaction=nonstopmode','-halt-on-error','-output-directory',str(out),'rigidity.tex'],cwd=root/'paper',capture_output=True,text=True,timeout=120)
        (out/f'build_{i+1}.log').write_text(run.stdout+run.stderr)
        if run.returncode:raise SystemExit(f'Build failed: {out}/build_{i+1}.log')
    print(out/'rigidity.pdf')
if __name__=='__main__':main()
