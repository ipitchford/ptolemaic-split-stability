#!/usr/bin/env python3
"""Replay the finite certificates and corroboration of research bundle v0.2.

This is a record of operations, not proof-assistant verification of the analytic theorems.
Modes: exact (rational + symbolic identities; byte-identical reports required), full (adds the
seeded numerical corroboration, the optimisation search and the LP discovery script; byte
matches are recorded but not required), and --with-baseline (extracts the unchanged companion
archive and runs its own exact replay).
"""
from __future__ import annotations
import argparse, hashlib, json, os, pathlib, subprocess, sys, time, zipfile

def digest(path: pathlib.Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()

def verify_manifest(root: pathlib.Path) -> int:
    manifest = root / 'SHA256SUMS'; entries = {}
    for line in manifest.read_text().splitlines():
        if not line.strip(): continue
        h, relative = line.split('  ', 1)
        p = (root / relative).resolve()
        if root not in p.parents or not p.is_file(): raise RuntimeError(f'Invalid manifest path: {relative}')
        if digest(p) != h: raise RuntimeError(f'Checksum mismatch: {relative}')
        entries[relative] = h
    actual = {str(p.relative_to(root)) for p in root.rglob('*') if p.is_file() and p.name != 'SHA256SUMS' and '__pycache__' not in p.parts}
    if actual != set(entries): raise RuntimeError(f'Manifest coverage mismatch: {sorted(actual ^ set(entries))}')
    return len(entries)

def safe_extract(archive: pathlib.Path, dest: pathlib.Path):
    dest.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(archive) as z:
        for item in z.infolist():
            p = (dest / item.filename).resolve()
            if p != dest and dest not in p.parents: raise RuntimeError('Unsafe ZIP path')
            if (item.external_attr >> 16) & 0o170000 == 0o120000: raise RuntimeError('Symlink in ZIP')
        z.extractall(dest)

def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--mode', choices=['exact', 'full'], default='exact')
    ap.add_argument('--with-baseline', action='store_true')
    ap.add_argument('--output', type=pathlib.Path, required=True)
    args = ap.parse_args()
    if sys.flags.optimize: raise SystemExit('Run without -O.')
    root = pathlib.Path(__file__).resolve().parent; out = args.output.resolve()
    if root == out or root in out.parents: raise SystemExit('Output must be outside the archive.')
    if out.exists() and any(out.iterdir()): raise SystemExit('Use a fresh empty output directory.')
    out.mkdir(parents=True, exist_ok=True)
    report = {'version': '0.2', 'mode': args.mode, 'with_baseline': args.with_baseline, 'formal_proof_assistant_used': False,
              'scope': 'Finite identities, exact certificate checks and optional bounded numerical corroboration; not universal proof validation.', 'jobs': []}
    env = os.environ.copy(); env['PYTHONDONTWRITEBYTECODE'] = '1'; env['PYTHONHASHSEED'] = '0'
    def job(name, command, cwd, timeout=1800):
        start = time.monotonic()
        proc = subprocess.run(command, cwd=cwd, env=env, capture_output=True, text=True, timeout=timeout)
        (out / (name + '.log')).write_text(proc.stdout + proc.stderr)
        item = {'job': name, 'exit_code': proc.returncode, 'elapsed_seconds': round(time.monotonic() - start, 3)}
        report['jobs'].append(item)
        if proc.returncode: raise RuntimeError(f'{name} failed; inspect log')
        return item
    try:
        report['manifest_files_verified'] = verify_manifest(root)
        gen = out / 'generated'; gen.mkdir()
        py = sys.executable; code = root / 'code'
        jobs = [('exact', [py, str(code / 'verify_exact.py'), '--output', str(gen)], ['exact_results.json', 'local_stability_certificate.json'], True),
                ('symbolic', [py, str(code / 'verify_symbolic.py'), '--output', str(gen)], ['symbolic_results.json'], True)]
        if args.mode == 'full':
            jobs += [('numerical', [py, str(code / 'verify_numerical.py'), '--output', str(gen)], ['numerical_results.json', 'numerical_trials.jsonl'], False),
                     ('search', [py, str(code / 'search_equality.py'), '--output', str(gen), '--starts', '300'], ['equality_search_results.json', 'equality_search_trials.jsonl'], False),
                     ('lp_discovery', [py, str(code / 'discover_lp_certificates.py'), '--output', str(gen)], ['lp_discovery.json'], False)]
        for name, cmd, files, required in jobs:
            item = job(name, cmd, root); item['reports'] = {}
            for f in files:
                same = (gen / f).read_bytes() == (root / 'results' / f).read_bytes()
                item['reports'][f] = {'sha256': digest(gen / f), 'matches_shipped_bytes': same, 'exact_byte_match_required': required}
                if required and not same: raise RuntimeError(f'Exact report mismatch: {f}')
            if name in ('numerical', 'search'):
                status = json.loads((gen / files[0]).read_text())['status']
                item['self_reported_status'] = status
                if status != 'PASS': raise RuntimeError(f'{name} reported {status}')
        if args.with_baseline:
            extraction = out / 'baseline'; safe_extract(root / 'provenance/evidencepress_ptolemaic_v1_0.zip', extraction)
            base = extraction / 'evidencepress_ptolemaic_v1_0'; dest = out / 'baseline_replay'
            item = job('baseline_exact', [py, str(base / 'replay_publication.py'), '--mode', 'exact', '--output', str(dest)], base)
            br = json.loads((dest / 'REPLAY_REPORT.json').read_text())
            item['nested_status'] = br['status']; item['nested_jobs'] = len(br['jobs']); item['nested_manifest_files'] = br['manifest_files_verified']
            if br['status'] != 'PASS': raise RuntimeError('Baseline nested replay did not pass')
        report['manifest_files_verified_after_replay'] = verify_manifest(root)
        report['status'] = 'PASS'
    except Exception as exc:
        report['status'] = 'FAIL'; report['error'] = str(exc)
    (out / 'REPLAY_REPORT.json').write_text(json.dumps(report, indent=2, sort_keys=True) + '\n')
    print(json.dumps({'status': report['status'], 'manifest_files': report.get('manifest_files_verified'), 'jobs': len(report['jobs']),
                      'receipt': str(out / 'REPLAY_REPORT.json'), 'error': report.get('error')}, indent=2))
    if report['status'] != 'PASS': raise SystemExit(1)

if __name__ == '__main__':
    main()
