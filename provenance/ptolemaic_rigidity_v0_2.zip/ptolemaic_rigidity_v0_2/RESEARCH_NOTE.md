# Rigidity at the sharp Ptolemaic negative-type threshold
## Equality classification for $m\ge6$ and sharp local seven-point stability

Research version 0.2 · 27 September 2026

**Abstract.** The companion manuscript proves the sharp universal negative-type exponent $p_m=\log_2(1+m/\lfloor(m-1)^2/4\rfloor)$ of $m$-point Ptolemaic metrics for $m\ge6$. We classify every metric attaining equality at that exponent. For $m=2k+1\ge7$ there is one similarity type, the complete split metric $\operatorname{CS}(k,k+1)$; for $m=2k\ge8$ there are exactly two, $\operatorname{CS}(k-1,k+1)$ and $\operatorname{CS}(k,k)$, exchanged by metric inversion. The same argument, run at the endpoint $p_6=1$ with the five-point strictness of Ercan as an external input, gives the two six-point types $\operatorname{CS}(2,4)$ and $\operatorname{CS}(3,3)$. Geometrically, the equality metrics are exactly the split metrics whose two snowflaked regular simplices have squared circumradii adding up to the squared cross-distance; the equality vector is the affine dependence expressing the coincidence of their centres. The decisive lemma classifies equality in the companion's conditioned correlation estimate whenever its inverse-deletion compatibility inequality has strict slack; its proof forces an inverted metric to be an equal-arm star. The balanced even case reduces to the adjacent case by Ercan's coefficient transport through inversion. For seven points we prove a first-order law: with mean cross-distance one and entrywise deviation $h$ from $\operatorname{CS}(3,4)$, the least negative-type gap on the unit zero-sum sphere equals $\frac{4p_7}{21}[2\sum(1-d_{aa'})+\sum(2-d_{bc})]$ up to an explicit $O(h^2)$ error, so that to first order it depends only on the shrinkage of the nine within-part edges. An exact linear-programming certificate then gives $\frac{2p_7}{21}h-28h^2\le\Delta\le\frac{16p_7}{7}h+\frac12h^2$ for $h\le1/100$; both first-order constants are attained. In particular $h/20\le\Delta\le2h$ for $h\le1/1000$. Linear stability extends to every diameter-normalised class with fixed positive separation, and collisions show that separation cannot be dropped.

[Typeset paper](paper/rigidity.pdf) · [LaTeX source](paper/rigidity.tex)

*This Markdown rendering was generated from the LaTeX source with pandoc; theorem, equation and table numbers follow the PDF only approximately, and cross-references are given as bare numbers. The PDF is the reference text.*

**Status and dependency.** Unrefereed research draft. The classification for $m\ge7$ uses the threshold, star-packing and conditional inverse-correlation theorems of the supplied companion manuscript, version 1.0, as explicit premises; the six-point case additionally uses external five-point strictness. The classification proof is analytic. The stability constants use finite rational certificates reproduced by two independent implementations. None of this is proof-assistant verification, external specialist review, or an exhaustive historical-priority audit.

# The equality problem and the results

A finite metric $d$ is *Ptolemaic* when $$d(i,j)d(k,l)\le d(i,k)d(j,l)+d(i,l)d(j,k)$$ for every four indices. It has $p$-negative type if its entrywise powered distance matrix $E_p=(d(i,j)^p)$ satisfies $z^{\mathsf T}E_pz\le0$ whenever $\mathbf 1^{\mathsf T}z=0$, and strict $p$-negative type if the inequality is strict for every nonzero such $z$. Put $$D_m=\left\lfloor\frac{(m-1)^2}{4}\right\rfloor,
 \qquad T_m=1+\frac m{D_m},\qquad p_m=\log_2T_m.$$ The companion manuscript proves negative type at $p_m$ for $m\ge6$ and strict negative type below that exponent, and its Proposition 6.1 proves strictness for all smaller cardinalities in the sub-one range, without importing the five-point endpoint. For $m\ge7$ one has $0<p_m<1$; for $m=6$, $p_6=1$.

An *equality metric* is a Ptolemaic metric on exactly $m$ distinct points for which $$z\ne0,\qquad \mathbf 1^{\mathsf T}z=0,\qquad z^{\mathsf T}E_{p_m}z=0$$ holds for some vector $z$, called an *equality vector*. All distinct-point distances are strictly positive; pseudometrics with coincident points are not included.

For positive integers $a,r$, the metric $\operatorname{CS}(a,r)$ has two parts $A,B$ of sizes $a,r$. All distinct distances are one except distances within $B$, which are two. It is the shortest-path metric of the complete split graph with clique $A$ and independent set $B$. *Similarity* means a positive common rescaling of distances followed by relabelling.

**Theorem 1** (All equality metrics for $m\ge7$). *The equality metrics are exactly:*

1.  *for $m=2k+1\ge7$, the similarities of $\operatorname{CS}(k,k+1)$;*

2.  *for $m=2k\ge8$, the similarities of $\operatorname{CS}(k-1,k+1)$ and $\operatorname{CS}(k,k)$.*

*Each equality metric has a one-dimensional equality space on $\mathbf 1^\perp$. For its displayed split, that space is spanned by the vector taking value $1/a$ on $A$ and $-1/r$ on $B$. Its $p_m/2$-snowflake has affine dimension $m-2$ and every proper subset is affinely independent.*

In particular, after rescaling, every seven-point equality metric has three points mutually at distance one, four points mutually at distance two, and all cross-distances one. There is no additional continuous family modulo similarity.

**Theorem 2** (Six points). *Assume that every Ptolemaic metric on at most five points has strict $1$-negative type. Then the six-point equality metrics, at $p_6=1$, are exactly the similarities of $\operatorname{CS}(2,4)$ and $\operatorname{CS}(3,3)$, with the same description of equality vectors and snowflakes as in 1.*

The hypothesis holds: five-point Ptolemaic metrics have $\log_2(9/4)$-negative type by , and his Theorem 6.2 states strict $q$-negative type for $1\le q<\log_2(9/4)$; four-point Ptolemaic metrics have $\log_23$-negative type by , and every three-point metric is Euclidean. In each case strict $1$-negative type follows from the strict-descent theorem of , which states that $p$-negative type of a metric space implies strict $q$-negative type for every $0\le q<p$. We keep the hypothesis explicit because it is the only input not supplied by the companion.

**Theorem 3** (Seven-point first-order law and sharp linear stability). *Let $p_*=p_7=\log_2(16/9)$ and let $d$ be a Ptolemaic metric on the labelled point set of $s=\operatorname{CS}(3,4)$, normalised so that the mean of the twelve cross-distances is one. Let $h=\max_{i<j}|d(i,j)-s(i,j)|$, let $\Delta(d)$ be the least eigenvalue of $-d^{p_*}$ on the zero-sum space, and let $$\ell(d)=12\sum_{a<a'\in A}\bigl(1-d(a,a')\bigr)+6\sum_{b<c\in B}\bigl(2-d(b,c)\bigr).$$ If $h\le1/100$, then $$\frac{2p_*}{63}\ell(d)-26h^2\le\Delta(d)\le\frac{2p_*}{63}\ell(d)+\frac12h^2,
 \qquad 3h-\frac{117}{2}h^2\le\ell(d)\le72h,$$ so that $$\frac{2p_*}{21}h-28h^2\le\Delta(d)\le\frac{16p_*}{7}h+\frac12h^2 .$$ The constants $2p_*/21$ and $16p_*/7$ are the exact one-sided limits of $\Delta(d)/h$ as $h\to0$ over Ptolemaic metrics. For $h\le1/1000$ one has $h/20\le\Delta(d)\le2h$.*

The sharp threshold was formulated in the triangular-hyperfield setting by , whose identity $q(n)=P(n-1)$ connects it with the universal exponent $P(m)$ of $m$-point Ptolemaic metrics; settled $P(5)$ and $P(6)$ and introduced the coefficient transport under inversion used in 5; the companion manuscript proves the all-cardinality threshold and explicitly leaves equality classification open. Ercan’s Theorem 6.2 records, for five points, the system of conditions equivalent to equality without identifying its solutions. The new steps here are the strict-slack equality lemma of 3, its gluing across pole pairs, the observation that the transported potential of an equality vector is a nonzero constant, and the quantitative seven-point analysis. We make no new claim about the classical Gram, Schur-complement or inversion identities. The primary sources and a bounded search are recorded in the source ledger.

# Inputs from the companion proof

Fix $0<p<1$, write $T=2^p$, and let $\mathsf S_p(j)$ mean that *every* Ptolemaic metric on at most $j$ points has strict $p$-negative type. The quantifier includes inverted metrics, not just subsets of one specified array. The companion proves the statements collected in this section for $0<p<1$; 10 supplies the instances needed at $p=1$.

For a rooted powered metric, let $r_i=d(0,i)^p$ and $$C_{ij}=\frac{r_i+r_j-d(i,j)^p}{2},\qquad C_{ii}=r_i.$$ Then $z^{\mathsf T}E_pz=-2(z')^{\mathsf T}Cz'$ for $z\in\mathbf 1^\perp$, where $z'$ omits the root coordinate. Thus strict negative type is equivalent to $C\succ0$.

For a Gram matrix of order $n$, the companion packing and inverse results use $$L_n(T)=\max\left\{2,\frac{2n}{2n-(n-1)T}\right\},\qquad
 k_n(T)=1-\frac2{L_n(T)}
 =\max\left\{0,\frac{(n-1)T-n}{n}\right\}.$$ Adjoin an infinity index to $E_p$ to obtain $$A=\begin{pmatrix}0&\mathbf 1^{\mathsf T}\\\mathbf 1&E_p\end{pmatrix}.$$ If $\mathsf S_p(n+1)$ holds, every two-by-two principal block of $A^{-1}$ is negative definite (companion Lemma 4.4). Consequently $$\rho_{ij}(A)=\frac{(A^{-1})_{ij}}
 {\sqrt{[-(A^{-1})_{ii}][-(A^{-1})_{jj}]}}$$ is well-defined and has absolute value less than one. The companion Theorem 5.1 gives $$\rho_{ij}(A)\ge-k_n(T)
 \quad\text{if }n\ge3,\quad T\le\frac n{n-2};$$ its $n=2$ conclusion holds without the displayed parameter condition.

Deleting an index $l$ from $A$ gives the inverse Schur identity $$\gamma'=
 \frac{\gamma-st}{\sqrt{(1-s^2)(1-t^2)}},$$ where $\gamma=-\rho_{ij}$, $s=-\rho_{il}$ and $t=-\rho_{jl}$. Positive diagonal congruence leaves these normalised inverse entries unchanged. Normalising any row of $A$ to ones corresponds to metric inversion, which preserves the Ptolemaic class . Inversion at a finite point $v$ replaces it by $\infty$ and gives $$\widehat d(i,j)=\frac{d(i,j)}{d(v,i)d(v,j)},\qquad
 \widehat d(\infty,i)=\frac1{d(v,i)}.$$ Inversion is an involution: inverting $\widehat d$ at $\infty$ returns $d$. Inversion of $\lambda d$ at $v$ gives $\lambda^{-1}\widehat d$.

Finally put $$u=C^{-1}r,\quad v=C^{-1}\mathbf 1,\quad M=\mathbf 1^{\mathsf T}u=r^{\mathsf T}v,
 \quad U=\mathbf 1^{\mathsf T}C^{-1}\mathbf 1,\quad V=r^{\mathsf T}C^{-1}r.$$ The augmented inverse has distinguished entry $$\rho_{\infty0}=\frac{2-M}{\sqrt{UV}},\qquad UV\ge M^2,$$ with equality in the second relation exactly when $r$ is a multiple of $\mathbf 1$, by Cauchy–Schwarz in the $C^{-1}$ inner product. If $u\ge0$ or $v\ge0$, the companion Lemma 4.1 gives $M\le L_n(T)$. More specifically, for root lengths $\ell_i=d(0,i)$ let $$R_{ii}=r_i,\qquad R_{ij}=\frac{r_i+r_j-(\ell_i+\ell_j)^p}{2},
 \quad B=R\operatorname{diag}(r)^{-1}.$$ The triangle inequality gives $C\ge R$ entrywise. When $v\ge0$, the vector $w=\operatorname{diag}(r)v$ satisfies $Bw=Rv\le Cv=\mathbf 1$, and the companion packing theorem (Theorem 3.4) gives $\mathbf 1^{\mathsf T}w\le L_n(T)$. These are the only parts of the star argument needed to classify equality below. For $0<p<1$ they are proved in the companion; 10 records what remains of them at $p=1$.

# An equality lemma for conditioned correlations

**Lemma 4** (Strict inverse slack forces a star). *Let $A$ augment the powered metric $d^p$ of an $(n+1)$-point Ptolemaic metric $d$, and assume that the inputs of 2 are available at this $p$: the bound (2.2) at orders $n$ and $n-1$, the inverse-block and inversion-closure lemmas, (2.5) and the packing bound. This is the case for $0<p<1$, and for $p=1$, $n=3$ by 10. Suppose $n\ge3$, $\mathsf S_p(n+1)$ holds, $k_n(T)>0$, and $$T<\frac n{n-2}.$$ If $\rho_{ij}(A)=-k_n(T)$ for two indices $i\ne j$ of $A$, let $\widehat d$ be $d$ itself when $i$ is the augmentation index, and the inversion of $d$ at $i$ otherwise. Then $\widehat d$ is an equal-arm star centred at the point $j$ of $\widehat d$ (the point $\infty$ of (2.4) when $j$ is the augmentation index): for some $L>0$, $\widehat d(j,x)=L$ and $\widehat d(x,x')=2L$ for all distinct $x,x'\ne j$.*

*Proof.* Write $\gamma=k_n(T)$. By (2.2), the selected entry is a most negative normalised entry. Also $$k_{n-1}(T)<\frac{k_n(T)}{1+k_n(T)}<k_n(T).$$ If $k_{n-1}=0$, this follows from $k_n>0$. If both are positive, the first difference is $$\frac{k_n}{1+k_n}-k_{n-1}
 =\frac{(T-1)[n-(n-2)T]}{T(n-1)}>0.$$ For any third index $l$, delete $l$ from $A$. The deleted matrix is diagonally congruent to the augmented matrix of an $n$-point Ptolemaic metric, so (2.2) at order $n-1$ gives $\gamma'\le k_{n-1}$; the parameter condition at order $n-1$ follows from (3.1) because $n/(n-2)$ decreases in $n$. If $st\le0$ in (2.3), then $\gamma'\ge\gamma-st\ge\gamma>k_{n-1}$, impossible. Thus the two incident inverse entries have the same nonzero sign. If both were negative, maximality gives $0<s,t\le\gamma<1$, and $$\gamma'\ge\frac{\gamma-st}{1-st}
 \ge\frac{\gamma-\gamma^2}{1-\gamma^2}
 =\frac{\gamma}{1+\gamma}>k_{n-1},$$ another contradiction; here $(1-st)^2-(1-s^2)(1-t^2)=(s-t)^2\ge0$ and $(\gamma-x)/(1-x)$ decreases in $x$. Every other inverse entry incident to the selected pair is therefore positive.

Regauge the pair as infinity and root; the underlying metric is $\widehat d$ rooted at $j$, its Gram matrix $C$ is positive definite by $\mathsf S_p(n+1)$, and the augmented inverse formula gives $u,v>0$. Since $\rho_{\infty0}=-k_n<0$, one has $M>2$. The packing bound and (2.5) give $$-k_n=\frac{2-M}{\sqrt{UV}}
 \ge\frac{2-M}{M}\ge\frac2{L_n}-1=-k_n.$$ Both inequalities are equalities. Hence $M=L_n>2$ and $UV=M^2$, so $r=r_0\mathbf 1$ for a positive scalar $r_0$: all raw root lengths of $\widehat d$ are equal to some $L>0$.

Put $c=1-T/2$. The equal-length star has $B=(1-c)I+c\mathbf 1\mathbf 1^{\mathsf T}$, and $w=r_0v>0$ satisfies $Bw\le\mathbf 1$ and $\sum w_i=M=L_n=n/[1+(n-1)c]$. Summing the $n$ row inequalities of $Bw\le\mathbf 1$ gives $M[1+(n-1)c]\le n$ with equality, so each row is an equality: $w_i=1/[1+(n-1)c]$ for every $i$, and $Rv=Bw=\mathbf 1=Cv$. It follows that $(C-R)v=0$. Every entry of $C-R$ is nonnegative and every entry of $v$ is positive; therefore $C=R$, that is, $\widehat d(x,x')^p=(2L)^p$ for all leaves $x\ne x'$. ◻

**Corollary 5** (Rigidity of a sharp anchor–pole pair). *Consider $a\ge2$ anchors and two poles $b,c$ in a Ptolemaic metric on these $a+2$ points, with the inputs of 4 available at $n=a+1$, $\mathsf S_p(a+2)$, $\kappa_a(T)=(aT-a-1)/(a+1)>0$, and $$T<\frac{a+1}{a-1}.$$ Root the Gram matrix at an anchor and let $S$ be the Schur complement of the anchor block, indexed by the poles. Then $S_{bc}=-\kappa_a(T)\sqrt{S_{bb}S_{cc}}$ if and only if, for some $\lambda>0$, all anchor–anchor and anchor–pole distances equal $\lambda$ and $d(b,c)=2\lambda$.*

*Proof.* The pole block of the augmented inverse is $-S^{-1}/2$, and the two-by-two inverse formula gives $\rho_{bc}(A)=S_{bc}/\sqrt{S_{bb}S_{cc}}$ (companion, equation (5.9)); in particular this ratio does not depend on the anchor chosen as root. Also $\kappa_a(T)=k_{a+1}(T)$. Apply 4 with $n=a+1$, $i=b$ and $j=c$: the inversion $\widehat d$ of $d$ at $b$ is an equal-arm star centred at $c$ whose leaves are the old infinity and the $a$ anchors. If the arm length is $L$, then $$L=\widehat d(c,\infty)=1/d(b,c),\qquad
 2L=\widehat d(\infty,x)=1/d(b,x)$$ for every anchor $x$. Thus $d(b,x)=d(b,c)/2$. The root-to-anchor condition $$\widehat d(c,x)=\frac{d(c,x)}{d(b,c)\,d(b,x)}=L$$ gives $d(c,x)=d(b,x)$, and the leaf-to-leaf condition $\widehat d(x,x')=2L$ gives $d(x,x')=d(b,x)$ for every anchor pair. Put $\lambda=d(b,c)/2$.

Conversely, in $\lambda\operatorname{CS}(a,2)$ the anchor circumradius squared in the powered embedding is $\lambda^p(a-1)/(2a)$. Both residual variances are $\lambda^p(a+1)/(2a)$, and their covariance is that variance minus $\lambda^pT/2$. The resulting correlation is $1-aT/(a+1)=-\kappa_a(T)$. ◻

The strict parameter condition is essential to this proof. At its equality endpoint the negative-triangle case can survive. It is exactly the case treated by inversion in the even classification below.

# From a null vector to a split metric

**Lemma 6** (Full support and the binding sign patterns). *Let $d$ be an equality metric on $m\ge7$ points. Every equality vector has full support. After reversing its sign, let its positive and negative supports have sizes $a\le r$. Then $$a+r=m,\qquad a(m-1-a)=D_m.$$ Thus $(a,r)=(k,k+1)$ for $m=2k+1$, and $(a,r)$ is $(k-1,k+1)$ or $(k,k)$ for $m=2k$. Moreover, with the positive points as anchors, every normalised pole residual pair has inner product $-1/(r-1)$.*

*Proof.* At $p=p_m<1$, every Ptolemaic metric of smaller cardinality $j<m$ has strict negative type, because $p_m<p_j$ and the companion’s Proposition 6.1 applies. A zero coordinate in the equality vector would therefore give a contradiction on the proper support. Normalise both absolute coefficient sums to one. A one-positive sign pattern has strictly positive deficit by the ordinary triangle inequality for the metric $d^p$, as in the companion proof. Hence $a\ge2$, $r\ge3$ and $a+2\le m-1$.

Choose one positive point as root and write the Gram matrix in anchor and pole blocks, with $K\succ0$, cross block $L$ and pole Schur complement $S$. Let $\alpha$ be the remaining positive coefficients, and $\beta_i>0$ the negative magnitudes. All $S_{ii}>0$, since the one-pole configurations are smaller metrics. The companion conditional inverse theorem on the two-pole configurations (Corollary 5.2 there, with $T_m\le F(a,r)\le(a+1)/(a-1)$) gives $$S_{ij}\ge-\kappa\sqrt{S_{ii}S_{jj}},\qquad
 \kappa=\max\left\{0,\frac{aT_m-a-1}{a+1}\right\}.$$ Set $t_i=\beta_i\sqrt{S_{ii}}>0$. The full, exact decomposition is $$\begin{aligned}
-\tfrac12z^{\mathsf T}E_pz
 &=\left\lVert K^{1/2}(\alpha-K^{-1}L\beta)\right\rVert^2
 +[1-(r-1)\kappa]\sum_i t_i^2\notag\\
 &\quad+\kappa\sum_{i<j}(t_i-t_j)^2
 +2\sum_{i<j}\beta_i\beta_j
       (S_{ij}+\kappa\sqrt{S_{ii}S_{jj}}).
\end{aligned}$$ Every term is nonnegative. In particular, if $$T_m<F(a,r):=\frac{(a+1)r}{a(r-1)}
 =1+\frac m{a(m-1-a)},$$ the second term is positive, since $1-(r-1)\kappa=\frac{a(r-1)}{a+1}[F(a,r)-T_m]$ when $\kappa>0$ and equals one otherwise; this contradicts equality. Since $T_m\le F(a,r)$ always, equality forces $T_m=F(a,r)$, which is (4.1); the integer solutions of $a(m-1-a)=D_m$ with $a\le m/2$ are the listed pairs. Then $\kappa=1/(r-1)>0$ and the second term vanishes identically. Every $t_i$ is equal and every pair slack vanishes, giving the stated normalised residual Gram matrix $$\left(\frac{S_{ij}}{\sqrt{S_{ii}S_{jj}}}\right)
 =\frac r{r-1}I-\frac1{r-1}\mathbf 1\mathbf 1^{\mathsf T}.$$ It has rank $r-1$ and is the Gram matrix of a regular simplex on the unit sphere. ◻

For seven points, 6 already gives a $3+4$ sign pattern and tetrahedral normalised residuals. The next step removes the possible freedom in the anchor triangle and in the residual lengths.

**Proposition 7** (Odd and adjacent-even rigidity). *If the binding sign pattern is unbalanced, $d$ is similar to $\operatorname{CS}(a,r)$ with the positive points as the clique.*

*Proof.* For $m=2k+1$, $a=k$ and $$\frac{a+1}{a-1}-T_m=\frac{k+1}{k^2(k-1)}>0.$$ For $m=2k$, $a=k-1$ and $$\frac{a+1}{a-1}-T_m=\frac2{(k-2)(k-1)}>0.$$ Thus 5 applies to every pair of negative points and the common anchor set, with $\mathsf S_p(a+2)$ supplied by the companion’s Proposition 6.1 as in 6. Every such $(a+2)$-point metric is a rescaled $\operatorname{CS}(a,2)$. Fix an anchor pair; its positive distance fixes the rescaling in all these subsets. Hence every anchor edge and every cross-edge has this common length, and every pole edge has twice it. ◻

# Balanced equality and metric inversion

The transport below is the quadratic-form covariance of , and the choice of an inversion point $v$ with $z_v\lambda>0$ is the support reduction of his Theorem 8.2; we restate the transport in our notation and add the two facts that matter for equality metrics.

**Lemma 8** (Transport of an equality vector). *If $d$ is an equality metric with $p=p_m$ and $z$ an equality vector, then $$E_pz=\lambda\mathbf 1\quad\text{with}\quad\lambda\ne0.$$ For inversion at a point $v$, the coefficients $$\widehat z_i=z_i d(v,i)^p\ (i\ne v),\qquad
 \widehat z_\infty=-\lambda$$ sum to zero and form an equality vector for the inverted metric, which is therefore an equality metric on $m$ points.*

*Proof.* Negative type makes $-E_p$ positive semidefinite on $\mathbf 1^\perp$. An equality vector is in its radical there, so $E_pz$ is orthogonal to $\mathbf 1^\perp$, giving the first formula with possibly zero $\lambda$. The coefficients in (5.1) sum to zero by that formula. Their quadratic form is $$\begin{aligned}
 \widehat z^{\mathsf T}\widehat E_p\widehat z
 &=\sum_{i,j\ne v}z_i z_j E_{ij}-2\lambda\sum_{i\ne v}z_i\\
 &=\sum_{i,j\ne v}z_i z_j E_{ij}+2\lambda z_v
 =z^{\mathsf T}E_pz=0 ,
\end{aligned}$$ using $\widehat E_p(i,j)=E_{ij}/(E_{vi}E_{vj})$ and $\widehat E_p(\infty,i)=1/E_{vi}$. If $\lambda=0$, the transported vector has a zero infinity coordinate but is not zero, since $z$ has full support by 6. Its support has at most $m-1$ points of the inverted Ptolemaic metric, contradicting strict negative type at that smaller cardinality. Thus $\lambda\ne0$, and $\widehat z\ne0$ is an equality vector for $\widehat d$. ◻

*Proof of 1.* The odd and adjacent-even cases follow from 7. In a balanced $k+k$ case, choose a point $v$ whose coefficient has the same sign as $\lambda$. After inversion at $v$ its replacement $\infty$ has coefficient $-\lambda$ of the opposite sign, while every other sign is unchanged. The new sign pattern is therefore $(k-1)+(k+1)$, after a possible overall reversal. By [lem:support,prop:unbalanced], the inverted metric is similar to $\operatorname{CS}(k-1,k+1)$, and the new infinity point belongs to its larger, independent part.

Inversion of the unscaled $\operatorname{CS}(a,r)$ at a clique point gives another $\operatorname{CS}(a,r)$. Inversion at an independent point gives $$\tfrac12\operatorname{CS}(r-1,a+1):$$ the remaining independent points form the new clique, and the old clique together with the new infinity point forms the new independent part. These statements follow immediately from the distances $1$ and $2$ in (2.4). Inversion is involutive and commutes with rescaling, so undoing the balanced-case inversion gives a similarity of $\operatorname{CS}(k,k)$. The two even types are distinct: their numbers of distance-two pairs are $\binom{k+1}{2}$ and $\binom{k}{2}$, and a similarity must preserve the set of pairs at the shortest distance.

Conversely, for either listed split take $z_i=1/a$ on $A$ and $z_i=-1/r$ on $B$. Its quadratic form is $$z^{\mathsf T}E_pz=\frac{a-1}{a}+\frac{r-1}{r}T_m-2=0 ,$$ because $T_m=F(a,r)$ for the binding pairs. The metric is Ptolemaic: the only nontrivial opposite-product comparison on four distinct points has products $2,1,1$.

For the displayed powered split, the restriction of $-E_p$ to $\mathbf 1^\perp$ has eigenvalues $1$ with multiplicity $a-1$, $T_m$ with multiplicity $r-1$, and zero once. This follows by taking contrasts within each part and the remaining constant-on-parts zero-sum vector. It proves uniqueness of the equality direction and affine dimension $m-2$. Every proper subset is affinely independent by the smaller-cardinality strictness already used above. ◻

*Remark 9* (Inversion orbits). For odd $m\ge7$, inversion at any vertex returns the same similarity type. For even $m\ge8$, the two listed types form one inversion orbit, with the independent-vertex inversion exchanging them. By , the supremal negative-type exponent of a finite metric space is never strict; hence 1 also identifies exactly the $m$-point Ptolemaic metrics whose own supremal exponent is the universal minimum $p_m$: a Ptolemaic metric has supremal exponent $p_m$ if and only if it is an equality metric, if and only if it is one of the listed split metrics.

# The endpoint $p=1$: six points

At $p=1$ the powered metric is $d$ itself. The companion states its Sections 3–5 for $0<p<1$. The proofs of [lem:inverse-rigidity,cor:pair-rigidity,prop:unbalanced] use those sections only through (2.2), (2.5), the packing bound $M\le L_n(T)$ for nonnegative $v$ or $u$, and the two $p$-independent lemmas on inverse blocks and inversion closure, and 2 needs them only for $n\le3$, $T=2$. We record what survives at the endpoint.

**Lemma 10** (The inputs at $p=1$, $n\le3$). *Let $p=1$, $T=2$, and let $C$ be the Gram matrix of an $(n+1)$-point metric rooted at $0$.*

1.  *If $n=2$ and $C\succ0$, then $u=C^{-1}r\ge0$ and $v=C^{-1}\mathbf 1\ge0$.*

2.  *If $C\succ0$ and $v\ge0$ or $u\ge0$, then $M\le n=L_n(2)$; when $v>0$ and $M=n$, all leaf distances are the sums of the root lengths, $d(i,j)=r_i+r_j$, and if in addition $UV=M^2$ the metric is an equal-arm star with all leaf distances twice the common root length.*

3.  *If $\mathsf S_1(4)$ holds, then (2.2) holds for $n=3$ with $k_3(2)=1/3$, all inputs of 4 are available at $p=1$, $n=3$, and [lem:inverse-rigidity,cor:pair-rigidity] hold for $n=3$, that is, for $a=2$ anchors.*

*Proof.* (i) With $r_1,r_2$ the root lengths and $\sigma=(r_1+r_2-d(1,2))/2$, the triangle inequalities give $0\le\sigma\le\min\{r_1,r_2\}$. Then $\det C\cdot v=(r_2-\sigma,r_1-\sigma)\ge0$ and $\det C\cdot u=(r_2(r_1-\sigma),r_1(r_2-\sigma))\ge0$.

\(ii\) At $p=1$ the star matrix is $R=\operatorname{diag}(r)$, and $C\ge R$ entrywise is the triangle inequality $C_{ij}\ge0$. If $v\ge0$, the $i$th row of $Cv=\mathbf 1$ gives $r_iv_i\le1$, so $M=r^{\mathsf T}v\le n$. If $u\ge0$, the $i$th row of $Cu=r$ gives $r_iu_i\le r_i$, so $M=\mathbf 1^{\mathsf T}u\le n$. Here $L_n(2)=\max\{2,n\}=n$ for $n\ge2$. If $v>0$ and $M=n$, then $r_iv_i=1$ for every $i$, so $(C-R)v=0$; nonnegative entries and positive $v$ force $C=R$, that is, $d(i,j)=r_i+r_j$ for all leaves $i\ne j$. Combined with the Cauchy–Schwarz equality in (2.5), which is unchanged, this gives the equal-arm star of 4 with $c=0$.

\(iii\) The companion’s proof of Theorem 5.1 at $n=3$ uses the $n=2$ base case, the inverse-block lemma (its Lemma 4.4) and inversion closure (its Lemma 4.3), the inverse-deletion identity (2.3), the compatibility $k_2\le k_3/(1+k_3)$, and, in the remaining case $u,v>0$, the packing bound. Item (i) supplies the base case with $u,v\ge0$, which is all that the lower bound $\rho_{\infty0}\ge-k_2=0$ needs; the two lemmas are $p$-independent given $\mathsf S_1(4)$, since they use only the inertia of $A$ and Ptolemaic inversion; the identity and the compatibility are $p$-independent, and (ii) supplies the packing bound. Strict slack $T=2<3=n/(n-2)$ holds, and (3.2) reads $0<1/4<1/3$. The proof of 4 then goes through verbatim with (ii) in place of the star computation, and 5 follows as before with $\kappa_2(2)=1/3$. ◻

*Proof of 2.* Let $d$ be a six-point equality metric at $p=1$ with equality vector $z$; negative type at $p_6=1$ is the companion’s Theorem 1.1 for $m=6$. The hypothesis $\mathsf S_1(5)$ replaces the companion’s Proposition 6.1 in 6: a zero coordinate of $z$ would contradict strictness on the proper support, so $z$ has full support; the one-positive pattern is excluded by the triangle inequality; and the remaining patterns are $2+4$ and $3+3$, both of which are binding since $F(2,4)=F(3,3)=2=T_6$.

For the $2+4$ pattern, the argument of 6 needs the two-pole bound $S_{ij}\ge-\frac13\sqrt{S_{ii}S_{jj}}$ for four-point Ptolemaic metrics with two anchors at $p=1$; this is 10(iii), and also at $q=1$. Equality forces $S_{ij}=-\frac13\sqrt{S_{ii}S_{jj}}$ for every pole pair, and 5 with $a=2$, valid by 10(iii), makes every anchor–pole–pole quadruple a rescaled $\operatorname{CS}(2,2)$. Gluing as in 7 gives $d\sim\operatorname{CS}(2,4)$.

For the $3+3$ pattern, 8 applies: its proof uses only negative type at the current exponent, full support and $\mathsf S_1(5)$. Choose $v$ with the sign of $\lambda$; inversion at $v$ produces an equality metric with the $2+4$ pattern, hence a similarity of $\operatorname{CS}(2,4)$ with $\infty$ in the independent part, and inverting back gives a similarity of $\operatorname{CS}(3,3)$ by (5.2). The converse statements and the spectrum are as in the proof of 1 with $T_6=2$. ◻

# Geometry of the equality metrics

**Proposition 11** (Two simplices with a common centre). *Let $a,r\ge2$, $m=a+r$, $0<p\le1$, $T=2^p$, and consider the $p/2$-snowflake of $\operatorname{CS}(a,r)$, whose squared distances are $1$ within $A$ and across, and $T$ within $B$. It embeds isometrically in Euclidean space as a regular $(a-1)$-simplex of side $1$ and a regular $(r-1)$-simplex of side $\sqrt T$ lying in orthogonal subspaces, with circumcentres at distance $\delta\ge0$ along a further orthogonal axis, where $$\delta^2=1-\rho_A^2-\rho_B^2,\qquad \rho_A^2=\frac{a-1}{2a},\qquad \rho_B^2=\frac{T(r-1)}{2r},$$ provided $\delta^2\ge0$; and $\delta^2\ge0$ is equivalent to $T\le F(a,r)$. Equality $T=F(a,r)$, that is $\delta=0$, holds exactly when the two circumcentres coincide. In that case the affine dimension is $m-2$ and the unique affine dependence is $\frac1a\mathbf 1_A-\frac1r\mathbf 1_B$, which is the equality vector.*

*Proof.* A regular simplex with $s$ vertices and squared side $\sigma$ has squared circumradius $\sigma(s-1)/(2s)$. Place the two simplices with their circumcentres on a common axis orthogonal to both spans, at distance $\delta$. Every cross squared distance is then $\rho_A^2+\rho_B^2+\delta^2$, which equals one exactly for the displayed $\delta^2$. The identity $\rho_A^2+\rho_B^2=1$ rearranges to $T=\frac{(a+1)r}{a(r-1)}=F(a,r)$, and $\delta^2\ge0$ to $T\le F(a,r)$. For $\delta=0$ the two centres coincide, so the barycentre of $A$ with weights $1/a$ equals the barycentre of $B$ with weights $1/r$; this is the affine dependence, and it is unique because the two simplices are affinely independent within their orthogonal subspaces. ◻

Thus $T_m=\min_aF(a,m-a)$ is exactly the exponent at which the two circumspheres of a maximally balanced split first touch at their centres, and the equality vector is the statement that the centres coincide. For seven points, at $p_*=\log_2(16/9)$, the squared distances of the snowflake of $\operatorname{CS}(3,4)$ are one within the three-point part and across, and $16/9$ within the four-point part. A centred Gram matrix is $$G_* = \operatorname{diag}\left(\tfrac12(I_3-J_3/3),\,
                 \tfrac89(I_4-J_4/4)\right),$$ where $J_s$ is the all-ones matrix of order $s$: an equilateral triangle of side one and a regular tetrahedron of side $4/3$, centred at the same point in orthogonal two- and three-dimensional subspaces, with squared circumradii $1/3$ and $2/3$.

The eigenvalues of $G_*$ are $1/2$ twice, $8/9$ three times, and zero twice. One zero is the automatic centring direction; the other is $$z_*=(4,4,4,-3,-3,-3,-3)/\sqrt{84}.$$ The smallest eigenvalue of a centred matrix on the *full* space is always zero. It must not be used as a stability statistic. We use the restricted gap below.

# Local stability at seven points

Write $s=\operatorname{CS}(3,4)$ with $A=\{0,1,2\}$ and $B=\{3,4,5,6\}$. For a Ptolemaic metric $d$ on these labelled points put $$\Delta(d)=\min\{-z^{\mathsf T}d^{p_*}z:\mathbf 1^{\mathsf T}z=0,\ \left\lVert z\right\rVert_2=1\}.$$ The companion theorem gives $\Delta(d)\ge0$, and 1 describes its zeros. Throughout this section $d$ is normalised so that the mean of the twelve cross-distances is one, $e=d-s$ is the vector of the $21$ edge perturbations with $x_{ab}$ on cross-edges, $y_{aa'}$ within $A$ and $t_{bc}$ within $B$, and $h=\left\lVert e\right\rVert_\infty$. The normalisation says $\sum x_{ab}=0$. The *shrinkage functional* is $$\ell(d)=-12\sum_{a<a'}y_{aa'}-6\sum_{b<c}t_{bc}
 =12\sum_{a<a'}\bigl(1-d(a,a')\bigr)+6\sum_{b<c}\bigl(2-d(b,c)\bigr).$$ We use the numerical bounds $$0.83<p_*<0.8301,\qquad 0.02634<\tfrac{2p_*}{63}<0.02636,$$ certified by $2^{83}\cdot9^{100}<16^{100}$ and $16^{10000}<2^{8301}\cdot9^{10000}$.

## The first-order law

Put $\Pi=I-J_7/7$ and let $H_0$ and $H_0+H$ be the restrictions of $-\Pi s^{p_*}\Pi$ and $-\Pi d^{p_*}\Pi$ to $\mathbf 1^\perp$. At $s$ the spectrum is $0,1,1,16/9,16/9,16/9$ with $H_0z_*=0$. Write $H_{\rm lin}$ for the restriction of $-\Pi(p_*s^{p_*-1}\circ e)\Pi$, where $\circ$ is the entrywise product and $s^{p_*-1}$ is $1$ on edges of length one and $2^{p_*-1}=8/9$ on pole edges.

**Lemma 12** (Derivative along the equality direction). *$z_*^{\mathsf T}H_{\rm lin}z_*=\frac{2p_*}{63}\ell(d)$.*

*Proof.* Since $\Pi z_*=z_*$, $z_*^{\mathsf T}H_{\rm lin}z_*=-2p_*\sum_{i<j}z_{*i}z_{*j}s_{ij}^{p_*-1}e_{ij}$. The products $z_{*i}z_{*j}$ are $16/84$ on anchor edges, $-12/84$ on cross-edges and $9/84$ on pole edges. The cross contribution vanishes because $\sum x_{ab}=0$, and the rest is $-\frac{2p_*}{84}\bigl[16\sum y_{aa'}+8\sum t_{bc}\bigr]=\frac{2p_*}{63}\ell(d)$. ◻

**Lemma 13** (Taylor bounds). *Let $0<h\le1/100$ and $q_2=\tfrac12p_*(1-p_*)(1-h)^{p_*-2}$. Then $q_2\le0.0715$, every entry of $d^{p_*}-s^{p_*}-p_*s^{p_*-1}\circ e$ has absolute value at most $q_2h^2$, and $$\begin{gathered}
\left\lVert H-H_{\rm lin}\right\rVert_2\le6q_2h^2\le0.429h^2,\qquad
 |z_*^{\mathsf T}(H-H_{\rm lin})z_*|\le\tfrac{41}{7}q_2h^2\le0.419h^2,\notag\\
 \left\lVert H_{\rm lin}\right\rVert_2\le6p_*h\le4.9806h .
\end{gathered}$$ Consequently $\varepsilon:=\left\lVert H\right\rVert_2\le4.985h\le0.05$.*

*Proof.* For an edge with $s_{ij}\in\{1,2\}$ and $|e_{ij}|\le h\le1/100$, Taylor’s formula with Lagrange remainder gives the entrywise bound with $\xi^{p_*-2}\le(1-h)^{p_*-2}$ for the intermediate point $\xi\ge1-h$; the bound on $q_2$ uses $p_*(1-p_*)<0.1412$ and $(1-h)^{p_*-2}<1.012$. The spectral norm of a symmetric matrix is at most its largest absolute row sum, and every row has six off-diagonal entries; compression to $\mathbf 1^\perp$ does not increase norms. The quadratic form bound uses $\sum_{i\ne j}|z_{*i}z_{*j}|=(24)^2/84-1=41/7$. For $H_{\rm lin}$ the row sums of $|p_*s^{p_*-1}\circ e|$ are at most $6p_*h$ on anchor rows and $\frac{17}{3}p_*h$ on pole rows. ◻

**Lemma 14** (A least-eigenvalue estimate). *Let $H_0$ be symmetric on a Euclidean space with $H_0z_*=0$ for a unit vector $z_*$ and $H_0\succeq I$ on $z_*^\perp$. Let $H$ be symmetric with $\left\lVert H\right\rVert_2=\varepsilon\le1/4$, and let $b$ be the component of $Hz_*$ orthogonal to $z_*$. Then $$z_*^{\mathsf T}Hz_*-\frac{|b|^2}{1-2\varepsilon}\le\lambda_{\min}(H_0+H)\le z_*^{\mathsf T}Hz_* ,$$ the least eigenvalue is simple, and its unit eigenvector $z$, with the sign fixed by $z^{\mathsf T}z_*>0$, satisfies $\left\lVert z-z_*\right\rVert_2\le|b|/(1-2\varepsilon)$.*

*Proof.* In the decomposition $\mathbb Rz_*\oplus z_*^\perp$ write $H_0+H=\bigl(\begin{smallmatrix}\alpha&b^{\mathsf T}\\ b&M\end{smallmatrix}\bigr)$ with $\alpha=z_*^{\mathsf T}Hz_*$ and $M\succeq(1-\varepsilon)I$. The upper bound is the Rayleigh quotient at $z_*$. Let $\lambda=\lambda_{\min}(H_0+H)$; then $\lambda\le\alpha\le\varepsilon<1-\varepsilon$, so $M-\lambda I\succ0$, and by interlacing the second smallest eigenvalue is at least $1-\varepsilon$, so $\lambda$ is simple. An eigenvector $(1,y)$ exists because $\lambda$ is not an eigenvalue of $M$, and the eigenvector equations give $y=-(M-\lambda I)^{-1}b$ and $\alpha-\lambda=b^{\mathsf T}(M-\lambda I)^{-1}b\le|b|^2/(1-\varepsilon-\lambda)\le|b|^2/(1-2\varepsilon)$. The same bound holds for $|y|$, and for the normalised eigenvector $\left\lVert z-z_*\right\rVert^2=2-2/\sqrt{1+|y|^2}\le|y|^2$. ◻

**Theorem 15** (First-order law). *If $h\le1/100$, then $$\frac{2p_*}{63}\ell(d)-26h^2\le\Delta(d)\le\frac{2p_*}{63}\ell(d)+\frac12h^2 ,$$ the least eigenvalue on $\mathbf 1^\perp$ is simple, and its unit eigenvector $z(d)$ with $z(d)^{\mathsf T}z_*>0$ satisfies $\left\lVert z(d)-z_*\right\rVert_2\le6h$.*

*Proof.* Apply 14 with $\varepsilon\le4.985h\le0.05$ from 13, so that $1-2\varepsilon\ge0.9003$. By [lem:derivative,lem:taylor], $|z_*^{\mathsf T}Hz_*-\frac{2p_*}{63}\ell(d)|\le0.419h^2$, which gives the upper bound. For the lower bound, $b$ is the component of $Hz_*$ orthogonal to $z_*$ and $H_{\rm lin}z_*=-\Pi g$ with $g_i=p_*\sum_js_{ij}^{p_*-1}e_{ij}z_{*j}$. Each $|g_i|\le p_*h\sum_j s_{ij}^{p_*-1}|z_{*j}|
=20p_*h/\sqrt{84}$ on every row, so $|g|\le20p_*h/\sqrt{12}=\frac{10p_*}{\sqrt3}h\le4.7926h$. Orthogonal projections do not increase norms, so $|b|\le4.7926h+0.429h^2\le4.797h$ and $|b|^2/(1-2\varepsilon)\le23.02h^2/0.9003\le25.57h^2$. Adding $0.419h^2$ gives the lower bound with $26h^2$. The eigenvector bound is $4.797h/0.9003\le5.33h$. ◻

*Remark 16* (First variation for every $m$). For any $m\ge6$ and either binding split $s=\operatorname{CS}(a,r)$, the least eigenvalue of $-\Pi d^{p_m}\Pi$ on $\mathbf 1^\perp$ is simple at $d=s$ by [thm:classification,thm:six], hence differentiable in $d$ near $s$ with derivative $z^{\mathsf T}(\mathrm dH)z$ for the unit equality vector $z$ . With mean cross-distance one the same computation as in 12 gives $$\Delta(d)=\frac{2p_m}{m}\Bigl[\frac ra\sum_{a<a'}\bigl(1-d(a,a')\bigr)
 +\frac{aT_m}{2r}\sum_{b<c}\bigl(2-d(b,c)\bigr)\Bigr]+O(h^2),$$ with an $O$-constant depending on $m$. For $(a,r)=(3,4)$ this is (8.6). To first order, the gap depends only on the shrinkage of within-part edges; cross-edge perturbations enter only at second order.

## The linear certificate

At the split metric, eighteen triangle constraints and eighteen Ptolemy constraints are active, and no others. Their linear slacks are $$\begin{aligned}
u_{a;bc}&=x_{ab}+x_{ac}-t_{bc},\notag\\
 v_{aa';bc}&=x_{ab}+x_{ac}+x_{a'b}+x_{a'c}-2y_{aa'}-t_{bc}.
\end{aligned}$$ Metricity gives $u\ge0$ exactly. The full Ptolemy slack differs from $v_{aa';bc}$ by $x_{ab}x_{a'c}+x_{ac}x_{a'b}-y_{aa'}t_{bc}$, so $$v_{aa';bc}\ge-3h^2 .$$ Order the $21$ edges lexicographically and let $D$ be the integer $36\times21$ matrix taking $e$ to the $36$ slacks in (8.7). Let $w$ be the indicator of the cross-edges. Then $\mathbf 1^{\mathsf T}De=9\sum x_{ab}-12\sum y_{aa'}-6\sum t_{bc}=\ell(d)$ under the normalisation. Also $\ker D=\mathbb Rs$: the triangle equalities force cross-perturbations to be independent of the anchor, and the Ptolemy equalities then force all cross-perturbations equal, with equal anchor perturbations and twice those perturbations on pole edges.

**Proposition 17** (Shrinkage controls the deviation). *For every Ptolemaic $d$ with mean cross-distance one, $$3h-\frac{117}{2}h^2\le\ell(d)\le72h .$$ The constants $3$ and $72$ cannot be improved: $\ell(d)/h$ tends to $3$ along the Ptolemaic family $$d_h=s+he_0+h^2e_1,\qquad 0<h\le\tfrac1{20},$$ where $e_0$ has $x_{a3}=x_{a4}=-\tfrac14$, $x_{a5}=x_{a6}=\tfrac14$ for every anchor $a$, $t_{34}=-1$, $t_{56}=\tfrac12$, all other entries zero, and $e_1$ is $-1$ on the nine within-part edges and zero on cross-edges; and $\ell(d)=72h$ along $d=s+he_1$.*

*Proof.* The upper bound is immediate from (8.2) and $|y|,|t|\le h$. For the lower bound, fix an edge $k$ and a sign $\sigma\in\{\pm1\}$. A *dual certificate* is a nonnegative vector $\eta\in\mathbb R^{36}$ and a scalar $\mu$ with $$D^{\mathsf T}(\mathbf 1-\eta)=\mu w+3\sigma\epsilon_k ,$$ where $\epsilon_k$ is the $k$th unit vector. Given such a certificate, and using $w^{\mathsf T}e=0$, $$3\sigma e_k=(\mathbf 1-\eta)^{\mathsf T}De-\mu w^{\mathsf T}e=\ell(d)-\eta^{\mathsf T}De
 \le\ell(d)+3h^2\,\eta^{\mathsf T}\mathbf 1_{\rm P},$$ where $\mathbf 1_{\rm P}$ indicates the eighteen Ptolemy rows, because triangle slacks are nonnegative and Ptolemy slacks are at least $-3h^2$ by (8.8). Certificates exist for all $42$ choices of $(k,\sigma)$; by the symmetry of the split under permutations of $A$ and of $B$ it suffices to display one per edge type and sign, and to symmetrise, with the values in Table 1. Direct substitution verifies (8.11) in each case, and the largest Ptolemy weight $\eta^{\mathsf T}\mathbf 1_{\rm P}$ is $39/2$. Choosing $k$ with $|e_k|=h$ and $\sigma=\operatorname{sign}(e_k)$ gives $3h\le\ell(d)+\frac{117}{2}h^2$.

For sharpness, $De_0\ge0$ with $\mathbf 1^{\mathsf T}De_0=3$, $w^{\mathsf T}e_0=0$ and $\left\lVert e_0\right\rVert_\infty=1$, while $De_1\ge\mathbf 1$ and $w^{\mathsf T}e_1=0$. Hence $d_h$ has mean cross-distance one, all linear slacks at least $h^2$, and the quadratic Ptolemy terms are at most $2(h/4)^2+h^2(h+h^2)<h^2$ in absolute value for $h\le1/20$. The inactive constraints have slack at least one at $s$; every entry of $d_h$ differs from $s$ by at most $h+h^2\le0.0525$, so an inactive triangle slack moves by at most $0.16$ and an inactive Ptolemy slack, a sum of three products of two distances, by at most $3[(2.0525)^2-4]<0.64$. Thus $d_h$ is Ptolemaic; its deviation is $h+h^2$ and $\ell(d_h)=3h+72h^2$. The family $s+he_1$ is Ptolemaic because its only tight quartet products are $(2-h)(1-h)\le2$. ◻

**Table 1.** Symmetrised dual certificates. Rows are labelled by the orbit of the active constraint under the stabiliser of the selected edge; $\eta$ is constant on each orbit. The last row gives the total weight on Ptolemy rows.

| anchor edge $01$ | $\sigma=+$ | $\sigma=-$ |
|---|---|---|
| $u_{a;bc}$, $a\in\{0,1\}$ | $5/6$ | $7/6$ |
| $u_{2;bc}$ | $13/12$ | $11/12$ |
| $v_{01;bc}$ | $5/4$ | $3/4$ |
| $v_{a2;bc}$ | $1$ | $1$ |
| $\mu$ | $-1/4$ | $1/4$ |
| $\eta^{\mathsf T}\mathbf 1_{\rm P}$ | $39/2$ | $33/2$ |

| cross edge $03$ | $\sigma=+$ | $\sigma=-$ |
|---|---|---|
| $u_{0;3c}$ | $5/6$ | $7/6$ |
| $u_{0;bc}$, $3\notin bc$ | $5/6$ | $7/6$ |
| $u_{a;3c}$, $a\ne0$ | $35/24$ | $13/24$ |
| $u_{a;bc}$, $a\ne0$, $3\notin bc$ | $17/24$ | $31/24$ |
| $v_{0a';3c}$ | $5/8$ | $11/8$ |
| $v_{0a';bc}$, $3\notin bc$ | $11/8$ | $5/8$ |
| $v_{12;3c}$ | $1$ | $1$ |
| $v_{12;bc}$, $3\notin bc$ | $1$ | $1$ |
| $\mu$ | $-1/4$ | $1/4$ |
| $\eta^{\mathsf T}\mathbf 1_{\rm P}$ | $18$ | $18$ |

| pole edge $34$ | $\sigma=+$ | $\sigma=-$ |
|---|---|---|
| $u_{a;34}$ | $2$ | $0$ |
| $u_{a;bc}$, $\lvert bc\cap34\rvert=1$ | $5/4$ | $3/4$ |
| $u_{a;56}$ | $0$ | $2$ |
| $v_{aa';34}$ | $1$ | $1$ |
| $v_{aa';bc}$, $\lvert bc\cap34\rvert=1$ | $3/4$ | $5/4$ |
| $v_{aa';56}$ | $2$ | $0$ |
| $\mu$ | $-1/2$ | $1/2$ |
| $\eta^{\mathsf T}\mathbf 1_{\rm P}$ | $18$ | $18$ |

The certificates were found by linear programming and are verified by exact rational substitution in the standard-library verifier and, independently, in the symbolic verifier. The value $3$ is the minimum of $\mathbf 1^{\mathsf T}De$ over the cone $\{De\ge0,\ w^{\mathsf T}e=0\}$ with $\left\lVert e\right\rVert_\infty=1$, computed as the least optimum of the $42$ linear programmes obtained by fixing $\sigma e_k=1$ and $|e_j|\le1$; the certificates are dual solutions. Symmetrised certificates, constant on the orbits of the stabiliser of the selected edge, form the solution set of a small linear system: it is a single point for the anchor edge and a one-parameter segment for the cross and pole edges, along which the Ptolemy weight is constant. The certificate of version 0.1 of this note, a rational left inverse with entries bounded by $4/9$, gives only $\frac94h$ in place of $3h$.

## Sharp linear stability

**Theorem 18** (Sharp linear stability). *If $h\le1/100$, then $$\frac{2p_*}{21}h-28h^2\le\Delta(d)\le\frac{16p_*}{7}h+\frac12h^2 .$$ If $h\le1/1000$, then $$\boxed{\frac h{20}\le\Delta(d)\le2h,}$$ the least direction on $\mathbf 1^\perp$ is unique up to sign, and $\left\lVert z(d)-z_*\right\rVert_2\le6h$. Moreover $$\liminf_{h\to0}\frac{\Delta(d)}{h}=\frac{2p_*}{21},\qquad
 \limsup_{h\to0}\frac{\Delta(d)}{h}=\frac{16p_*}{7},$$ the extreme values being approached along the families of 17.*

*Proof.* Insert (8.9) into (8.6): the lower bound is $\frac{2p_*}{63}(3h-\frac{117}{2}h^2)-26h^2$, and $\frac{2p_*}{63}\cdot\frac{117}{2}
=\frac{13p_*}{7}<1.542$, so $26+1.542<28$; the upper bound is $\frac{2p_*}{63}\cdot72h+\frac12h^2$. For $h\le1/1000$, (8.3) gives $\frac{2p_*}{21}-28h>0.07904-0.028>\frac1{20}$ and $\frac{16p_*}{7}+\frac h2<1.8974+0.0005<2$. Simplicity and the eigenvector bound are 15. Along $d_h$ of (8.10), whose deviation is $h+h^2$, (8.6) gives $\Delta(d_h)/(h+h^2)\to\frac{2p_*}{63}\cdot3$, and along $s+he_1$ it gives $\Delta/h\to\frac{2p_*}{63}\cdot72$; by (8.12) no Ptolemaic family can do better on either side. ◻

The lower constant $2p_*/21\approx0.0791$ is small because the extremal direction $e_0$ shrinks one pole edge by $h$ while lengthening another by $h/2$ and moving cross-edges by $h/4$, so that the weighted shrinkage (8.2) is only $3h$. The inward family with all pole edges $2-h$, used in version 0.1 to show that the linear exponent is optimal, has $\ell=36h$ and $\Delta\approx\frac{8p_*}{7}h$; it is neither extreme.

For an unnormalised metric with mean cross-distance $\lambda>0$, put $h=\left\lVert d/\lambda-s\right\rVert_\infty$. The scaled conclusion of (8.13) is $$\Delta(d)\ge\lambda^{p_*}h/20,
 \qquad \left\lVert d-\lambda s\right\rVert_\infty\le20\lambda^{1-p_*}\Delta(d)
 \qquad(h\le1/1000).$$

# Separated classes and the collision obstruction

For $0<\eta\le1/2$, let $\mathcal D_\eta$ consist of seven-point Ptolemaic metrics with maximum distance one and minimum distinct-point distance at least $\eta$. Let $\mathcal E$ be the $35$ relabelled copies of $s/2$ and use maximum entrywise distance.

**Corollary 19** (Global linear stability on a separated class). *There is a finite $C_\eta$ such that $$\operatorname{dist}_\infty(d,\mathcal E)\le C_\eta\Delta(d)
 \qquad(d\in\mathcal D_\eta).$$ The local part is explicit with constant $40$; this proof does not compute the constant on the complementary compact set.*

*Proof.* The class is compact and $\Delta$ is continuous. By 1, its zero set is exactly $\mathcal E$. Near any of these points, the mean cross-distance $\lambda$ is positive and the local normalisation in 18 applies. Since $\max d=1$, $|2\lambda-1|\le\lambda h$, and therefore $$\left\lVert d-s/2\right\rVert_\infty\le\lambda h+|2\lambda-1|\le2\lambda h
 \le40\lambda^{1-p_*}\Delta(d)\le40\Delta(d).$$ On the compact complement of these neighbourhoods, $\Delta$ has a strictly positive minimum $\nu_\eta$ if the complement is nonempty. All distances to $\mathcal E$ are at most one there, so $C_\eta=\max\{40,\nu_\eta^{-1}\}$ suffices. If the complement is empty, take $C_\eta=40$. ◻

A separation condition cannot be omitted from this type of conclusion. Take the seven points $0,\varepsilon,1,2,3,4,5$, with $0<\varepsilon<1$, on the real line and divide distances by five. Their diameter is one and they are Ptolemaic. The unit zero-sum vector supported on the first two points gives $$\Delta(d_\varepsilon)\le(\varepsilon/5)^{p_*}\longrightarrow0.$$ Every metric in $\mathcal E$ has minimum distance $1/2$, so $$\operatorname{dist}_\infty(d_\varepsilon,\mathcal E)\ge\frac12-\frac\varepsilon5
 \longrightarrow\frac12.$$ Thus no vanishing modulus in the gap alone can control distance to the non-colliding equality family on the entire diameter-normalised class. does not identify collision limits as additional equality metrics on seven distinct points.

# Verification, dependence and scope

The immutable companion archive is included with its original SHA-256. A fresh extraction passed its exact replay: 130 manifested files and five jobs, with its required exact reports unchanged. We did not rerun the predecessor’s exploratory full numerical workflow.

The standard-library verifier checks the split null vectors, centred spectra, vertex inversions, generic coefficient transports, the strict parameter comparisons for $6\le m\le300$, the two-simplex identities, the six dual certificates of Table 1 by exact substitution, the kernel and rank of $D$, the sharpness families of 17 by exact metric and Ptolemy checks at dyadic $h$, and the rational inequalities behind (8.3), 13 and 18. The symbolic verifier does not import that implementation: it differentiates the original metric inequalities to reconstruct $D$, re-derives the certificates from the constraint definitions, checks the derivative $2p_*/63$ symbolically together with the general first-variation coefficient of 16, the reference spectrum, the Taylor constants and the inward and extremal families. A discovery script records how the certificates were obtained by linear programming; the verifiers do not depend on it.

Bounded perturbation experiments check the two-sided law (8.6) and the linear bounds (8.12)–(8.13) in the correct zero-sum subspace on random Ptolemaic perturbations with $h$ up to $1/100$, and record the observed extreme ratios $\Delta(d)/h$ along the two families. A separate optimisation search minimises $\Delta$ over Ptolemaic metrics with distances in $[3/10,1]$ for $m=6,7,8$ from several hundred random starts and compares every near-zero minimiser with the split copies predicted by [thm:classification,thm:six] up to relabelling and rescaling. These are numerical corroboration, not an exhaustive search for equality metrics and not a proof.

The results prove a classification for positive finite metrics with $m\ge7$, the six-point classification relative to external five-point strictness, and an explicit seven-point local stability estimate with sharp first-order constants, all relative to the companion threshold and inverse theorems. They do not classify equality for $m\le5$, where $p_m>1$ and the companion machinery does not apply; do not give a stability bound uniform in $m$ beyond the first variation of 16; do not calculate an explicit global $C_\eta$; and do not remove the need for external review of either proof. The bounded literature check did not locate a consulted source stating this classification; no exhaustive priority conclusion follows from that search.

# References

Companion manuscript. (2026). *Sharp negative type of finite Ptolemaic metrics*. Unrefereed version 1.0, 25 September 2026. Evidence Press release package supplied in this research workflow. Preserved unchanged in `provenance/evidencepress_ptolemaic_v1_0.zip`.

Baker, M., Huh, J., Kummer, M., & Lorscheid, O. (2026). *Lorentzian polynomials and matroids over triangular hyperfields. Part 2: Analytic aspects* (Version 2) \[Preprint\]. arXiv. <https://arxiv.org/abs/2607.15375v2>

Ercan, E. (2026). *Ptolemaic negative type and the values $q(6)$ and $q(7)$* (Version 1) \[Preprint\]. arXiv. <https://arxiv.org/abs/2608.20606v1>

Kato, T. (1995). *Perturbation theory for linear operators* (Reprint of the 1980 edition). Springer. <https://doi.org/10.1007/978-3-642-66282-9>

Li, H., & Weston, A. (2010). Strict $p$-negative type of a metric space. *Positivity, 14*(3), 529–545. <https://doi.org/10.1007/s11117-009-0035-2>
