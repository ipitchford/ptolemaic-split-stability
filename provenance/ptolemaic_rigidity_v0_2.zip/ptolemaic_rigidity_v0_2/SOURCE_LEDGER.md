# Source and novelty ledger — version 0.2

**Search date:** 27 September 2026. This is a bounded literature check, not a systematic review or a priority certificate.

## Imported mathematical premise

**Companion manuscript (2026), *Sharp negative type of finite Ptolemaic metrics*, unrefereed v1.0, 25 September 2026.** The complete supplied source and its five-job exact replay were inspected. The note imports the threshold theorem (Theorem 1.1 there, $m\ge6$), Proposition 6.1 (universal strictness below smaller thresholds in the sub-one range), Theorem 3.4 (star packing), Lemma 4.1 (inverse pairing bound for nonnegative inverse vectors), Lemma 4.4 (inverse two-by-two blocks), Theorem 5.1 (inverse-correlation induction), Corollary 5.2 and equation (5.9) (conditioned correlations). For the six-point case only the $n\le3$, $p=1$ instances are used, and Lemma 6.1 of the note re-verifies them from scratch. The companion explicitly leaves equality classification open (its Section 8). This package does not turn the companion into an externally refereed result.

## Primary external sources

Baker, M., Huh, J., Kummer, M., & Lorscheid, O. (2026). *Lorentzian polynomials and matroids over triangular hyperfields. Part 2: Analytic aspects* (Version 2) [Preprint]. arXiv. https://arxiv.org/abs/2607.15375v2 — Conjecture 6.4, Proposition 6.1 (the split-type obstruction and $q(n)=O(1/n)$), Proposition 7.5 ($q(n)=P(n-1)$), Theorem 7.16 and Corollary 7.17 ($P(4)=\log_23$, formalised in Lean by the authors with D. Renshaw). Full text inspected. Supplies context and, for the six-point case, four-point negative type at $\log_23$. Does not classify equality.

Ercan, E. (2026). *Ptolemaic negative type and the values $q(6)$ and $q(7)$* (Version 1) [Preprint]. arXiv. https://arxiv.org/abs/2608.20606v1 — Theorem 1.1 ($P(5)$, $P(6)$), Proposition 4.3 (four-point Schur-complement bound with $\kappa_q=(2^{q+1}-3)/3$, sharp; at $q=1$ this is $1/3$), Theorem 6.2 (strictness of five-point Ptolemaic metrics for $1\le q<\log_2(9/4)$ and the equality system at the endpoint, with $\mathrm{CS}(2,3)$ shown to satisfy it but not shown unique), Lemma 7.1 (inversion closure), Theorem 8.1 (coefficient transport, involutive, quadratic form preserved) and Theorem 8.2 (support reduction by transport at a point with $c_p\Phi_c(p)>0$). Full text inspected. Lemma 5.1 of the note is Theorem 8.1 in our notation plus the facts specific to equality metrics; the balanced-case argument is the mechanism of Theorem 8.2 applied to an equality vector. Ercan's Bernstein certificate was not audited and is not a premise for $m\ge7$; for $m=6$ his Theorem 6.2 is a premise.

Li, H., & Weston, A. (2010). Strict $p$-negative type of a metric space. *Positivity, 14*(3), 529–545. https://doi.org/10.1007/s11117-009-0035-2 — abstract and statements inspected: $p$-negative type implies strict $q$-negative type for $0\le q<p$ (any metric space); the supremal $p$-negative type of a finite metric space cannot be strict. Used for the six-point hypothesis and for Remark 5.2.

Kato, T. (1995). *Perturbation theory for linear operators*. Springer. https://doi.org/10.1007/978-3-642-66282-9 — cited for first-order perturbation of a simple eigenvalue (Remark 8.5); the seven-point estimates are proved directly and do not rely on it.

## Search coverage and negative evidence

Queries combined "Ptolemaic", "negative type", "equality", "extremal", "rigidity", "complete split", "$q(n)$", "triangular hyperfield" and the arXiv identifiers 2607.15375 and 2608.20606; the full texts of the two preprints were searched for "equality", "extremal", "rigid", "unique" and "split". No consulted source states the equality classification for any $m\ge6$, the two-simplex characterisation, or a quantitative stability estimate at the threshold. Negative searches have little evidential weight; this does not establish historical novelty.

## Separation of origins

- Definitions, threshold, packing and inverse bounds: companion.
- Inversion closure, coefficient transport and the sign-shift mechanism: Ercan (2026).
- Strict descent and non-strictness of the supremal exponent: Li–Weston (2010).
- Strict-slack equality lemma, gluing, the nonzero constant transported potential, the all-size classification, the six-point endpoint argument, the two-simplex characterisation, the first-order law, the LP certificates and sharp constants, separated stability and the collision analysis: derived in this workflow (versions 0.1 and 0.2).
- Random perturbations and the optimisation search: implementation corroboration only.
