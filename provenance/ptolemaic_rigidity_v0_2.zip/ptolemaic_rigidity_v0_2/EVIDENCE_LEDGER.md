# Evidence ledger — version 0.2, 27 September 2026

## Logical status

The classification for $m\ge7$ is an analytic deduction from the supplied companion theorem and its proof machinery; the six-point classification additionally assumes strict 1-negative type of Ptolemaic metrics on at most five points, which follows from the cited external results. The companion is unrefereed. The seven-point stability theorems combine written analytic bounds with finite rational certificates (six dual certificates and a rational inequality chain). Neither the code nor this review amounts to proof-assistant verification or external specialist endorsement. Priority is unresolved.

## Source replay

The original `evidencepress_ptolemaic_v1_0.zip` is included unchanged (SHA-256 in `provenance/INPUT_SHA256.json`). The version 0.1 bundle was replayed in full mode with the nested companion replay before review: 32 manifested files, four jobs, all required exact reports byte-identical; nested replay 130 files, five jobs, PASS (`provenance/V01_REPLAY_REPORT.json`, `provenance/BASELINE_REPLAY_REPORT.json`). The predecessor's exploratory full numerical experiments were not rerun.

## Exact rational checks (`code/verify_exact.py`, standard library)

Seven groups. Parameter cases for $6\le m\le300$ (binding pairs, $\kappa=1/(r-1)$, strict slack exactly in the unbalanced patterns, two-simplex identity, positive centre separation for non-binding splits). Twenty split witnesses ($6\le m\le18$, both even types): 18,051 oriented triangle checks, 54,879 oriented Ptolemy checks, 240 vertex inversions, 240 generic coefficient transports and 240 equality-vector transports with sign-pattern and proportionality checks. Anchor–pole equality witnesses at $T=16/9$ ($a=3$) and $T=2$ ($a=2$). Endpoint inputs at $p=1$: 394 three-point and 383 four-point rational cases. Local certificate: $D$ is $36\times21$ of rank 20 with kernel $\mathbb R s$; the six symmetrised dual certificates of Table 1 are expanded and verified on all 42 edge–sign pairs; maximal Ptolemy weight $39/2$; primal directions with shrinkage $3$ and $72$; both sharp families exactly Ptolemaic at $h=2^{-5},\dots,2^{-14}$; the version 0.1 left inverse is retained for comparison (maximal entry $4/9$). Constant chain: $0.83<p_*<0.8301$ by integer comparison, $q_2\le0.0715$, $\varepsilon\le4.985h$, $|b|\le4.797h$, and the constants $26$, $28$, $1/20$, $2$, $6$ of Theorems 8.4 and 8.7. Eleven collision examples.

These finite checks do not prove the all-size theorem. The all-size argument is the analytic proof in the paper. The certificates and the constant chain, unlike the sampled families, directly participate in the stability constants.

## Independent symbolic reconstruction (`code/verify_symbolic.py`, SymPy)

Does not import the exact verifier. Scans all 210 triangle and Ptolemy inequalities of a seven-point metric, keeps the 36 active at $s$, reconstructs $D$ by differentiation and its quadratic Ptolemy remainders. Solves the symmetry-reduced dual systems for the three edge types and two signs, obtaining the certificate families (unique for the anchor edge; one free parameter otherwise) with Ptolemy weights $39/2$, $33/2$, $18$, $18$, $18$, $18$, and confirms the Table 1 points lie in them. Checks the derivative $2p_*/63$, the first-variation coefficient for seven $(a,r)$ pairs, the centred and restricted spectra, the three family derivatives ($8p_*/7$, $16p_*/7$, $2p_*/21$), the eigenvector inequality, the two-simplex identity, the compatibility factor, the strict-slack differences, the converse correlation, and the Taylor constants on the interval $0.83\le p\le0.8301$. Identity checks, not independent specialist review.

## Numerical corroboration (`code/verify_numerical.py`, seed 20260927)

4,000 random and 2,000 near-extremal Ptolemaic perturbations with $10^{-4}\le h\le10^{-2}$ (none rejected) satisfy every displayed inequality: the two-sided law, the certificate bounds, the linear bounds, $h/20\le\Delta\le2h$ when $h\le1/1000$, the eigenvector bound and simplicity. Observed extremes: $\Delta/h$ from $0.105$ (near-extremal sampler) to $1.74$; shrinkage $\ell/h$ down to $4.0$; maximal defect of the lower law $0.21h^2$ against the allowed $26h^2$, of the upper law $0.08h^2$ against $0.5h^2$. The families $s+he_0+h^2e_1$, $s+he_1$ and the version 0.1 inward family were followed to $h=2^{-15}$ at 70 digits; the ratios decrease monotonically to $2p_*/21$, $16p_*/7$ and $8p_*/7$ within $2\times10^{-4}$. Tolerances are not exact positivity certificates.

## Optimisation search (`code/search_equality.py`, seeds 20260933–20260935)

For $m=6,7,8$, 300 local minimisations of the restricted gap over Ptolemaic metrics with distances in $[3/10,1]$ from random Euclidean, snowflaked-Euclidean and perturbed-split starts. Feasible near-zero minimisers (gap below $10^{-7}$): 298, 253 and 282; every one lies within $1.1\times10^{-7}$ of a predicted split copy after relabelling and rescaling, and both even types occur for $m=6$ and $m=8$. The remaining feasible terminations are positive local minima with gap at least $0.026$ and distance at least $0.26$ from the splits (1, 36, 2 cases) or, for $m=7$, one termination at gap $1.3\times10^{-7}$ within $2\times10^{-6}$ of a split; infeasible terminations (violation above $10^{-7}$): 1, 10, 15. No feasible point with gap below $10^{-4}$ was found farther than $10^{-2}$ from the splits. This is local optimisation from random starts: corroboration of completeness, not an exhaustive search and not a proof.

## Linear-programming provenance (`code/discover_lp_certificates.py`)

Records how the certificates were obtained: primal minimum $3$ over the 42 edge–sign choices (values $3, 7.2, 9, 12, 18$ occur), maximum $72$, and the exact reduced dual families. The verifiers do not depend on this script.

## Build and inspection

The PDF is generated from the supplied LaTeX source with three pdflatex passes (`results/latex_build.log`, `results/PDF_QA.json`): fifteen pages, no overfull or underfull boxes, no undefined references, no missing characters. All pages were rendered and inspected; Table 1 was checked against the certificate data. The build environment lacked the `newtx` fonts, so the preamble's fallback to `txfonts` was used; with `newtx` installed the layout will differ slightly.

## Scope boundaries

Not proved here: equality classification for $m\le5$; a stability bound uniform in $m$ beyond the first variation; an explicit global constant on the complement of the seven-point local neighbourhood; any stability modulus without positive separation; historical priority; external specialist acceptance; the external five-point strictness used for $m=6$. No public release metadata are inferred from the archive's preparation.
