# Ptolemaic equality and rigidity — research bundle v0.2

**Date:** 27 September 2026. **Status:** unrefereed analytic proof draft, dependent on the supplied companion paper; reviewed and developed from version 0.1 inside the same workflow (`REVIEW_REPORT.md`, `CHANGELOG.md`). No external specialist review, proof-assistant verification or exhaustive priority claim is asserted.

## Main results

- **Classification, $m\ge7$ (Theorem 1.1).** The metrics attaining equality at the sharp exponent $p_m$ are exactly the similarities of $\mathrm{CS}(k,k+1)$ for $m=2k+1$ and of $\mathrm{CS}(k-1,k+1)$ or $\mathrm{CS}(k,k)$ for $m=2k$; the two even types are exchanged by inversion; the equality space is one-dimensional. For seven points: fifteen distances $\lambda$ and six distances $2\lambda$.
- **Six points (Theorem 1.2).** At $p_6=1$ the equality metrics are the similarities of $\mathrm{CS}(2,4)$ and $\mathrm{CS}(3,3)$, conditional on strict 1-negative type of Ptolemaic metrics on at most five points (which follows from Ercan 2026, Baker–Huh–Kummer–Lorscheid 2026 and Li–Weston 2010).
- **Geometry (Proposition 7.1).** Every binding split snowflakes to two regular simplices in orthogonal subspaces with a common centre; $T=F(a,r)$ is the identity $\rho_A^2+\rho_B^2=1$ of squared circumradii, and the equality vector is the coincidence of the centres.
- **Seven-point stability (Theorems 8.4, 8.7).** With mean cross-distance one and deviation $h$ from $\mathrm{CS}(3,4)$, the least gap on the unit zero-sum sphere satisfies $\Delta=\frac{2p_*}{63}\ell+O(h^2)$ with explicit error, where $\ell=12\sum(1-d_{aa'})+6\sum(2-d_{bc})$ is the shrinkage of the nine within-part edges. Exact dual certificates give $3h-\frac{117}{2}h^2\le\ell\le72h$, hence $\frac{2p_*}{21}h-28h^2\le\Delta\le\frac{16p_*}{7}h+\frac12h^2$ for $h\le1/100$; both first-order constants are attained. For $h\le1/1000$: $h/20\le\Delta\le2h$. (Version 0.1 had $h/25\le\Delta\le6h$ for $h\le1/5000$.)
- **Global stability on separated classes** with a non-explicit complement constant, and the **collision obstruction** without separation (Section 9).

## Read first

- `paper/rigidity.pdf`: fifteen-page paper with numbered statements and full arguments; `paper/rigidity.tex` is the source.
- `REVIEW_REPORT.md`: the review of version 0.1 (verdict, ranked findings, what was changed, what was not done).
- `RESEARCH_NOTE.md`: Markdown rendering of the paper (generated with pandoc; the PDF fixes the numbering).
- `review/REVIEW_GUIDE.md`: dependency audit and scrutiny priorities for an external reader.
- `CLAIM_CHECK_MAP.md`, `EVIDENCE_LEDGER.md`, `SOURCE_LEDGER.md`: which checks support which statements; exact, symbolic, numerical and imported evidence kept separate; premises and bounded external search.
- `CHANGELOG.md`, `STATUS.json`, `ENVIRONMENT.json`, `provenance/`.

## Reproduce

Python 3.11 was used. The rational verifier needs only the standard library; the symbolic verifier needs SymPy; the numerical verifier needs NumPy and mpmath; the search and the LP discovery script need SciPy.

```sh
python -m pip install -r requirements.txt
python replay.py --mode exact --output /tmp/rigidity-exact
python replay.py --mode full --with-baseline --output /tmp/rigidity-full
```

Use a fresh output directory **outside** the archive tree. `exact` runs the rational and symbolic verifiers and requires their reports to match the shipped ones byte for byte. `full` adds the seeded numerical corroboration (about two seconds), the optimisation search (about half a minute) and the LP discovery script; their byte matches are recorded but not required, and their self-reported status must be PASS. `--with-baseline` extracts the unchanged companion archive and runs its five-job exact workflow. A PASS receipt records these operations; it is not formal verification of the theorems. Do not run with Python `-O`.

Individual scripts:

```sh
python code/verify_exact.py --output /tmp/rigidity-rational
python code/verify_symbolic.py --output /tmp/rigidity-symbolic
python code/verify_numerical.py --output /tmp/rigidity-numerical
python code/search_equality.py --output /tmp/rigidity-search --starts 300
python code/discover_lp_certificates.py --output /tmp/rigidity-lp
```

`results/local_stability_certificate.json` contains the $36\times21$ active-constraint matrix, the six certificates' verification summary, the primal extremal directions and the sharp-family checks.

## Build the paper

```sh
python build_paper.py --output /tmp/rigidity-paper
```

Three pdflatex passes in an external directory. A TeX installation with amsmath, natbib, cleveref, booktabs and either newtx or txfonts is required (the preamble selects txfonts when newtx is absent). The bibliography is embedded; `paper/references.bib` is supplied for editing.

## What has and has not been released

This is a research deliverable for review, not a record of public deposition. No DOI, public licence, institutional affiliation, personal authorship or website deployment is assigned here. The companion manuscript is preserved unchanged in `provenance/evidencepress_ptolemaic_v1_0.zip` and is itself an unrefereed premise. The version 0.1 bundle is not included; its SHA-256 and replay receipt are in `provenance/`.
