#!/usr/bin/env python3
"""Optimisation search for endpoint equality metrics on m = 6, 7, 8 points.

For each m the restricted least eigenvalue Delta(d) of -d^{p_m} on the zero-sum space is minimised
over Ptolemaic metrics with all distances in [eta, 1], from many random starts (SLSQP, analytic
gradient).  Every converged minimiser with Delta below a tolerance is compared, up to relabelling
and rescaling, with the complete split metrics predicted by the classification.  This is numerical
corroboration of completeness of the classification; it is not a proof and not an exhaustive search.
"""
from __future__ import annotations
import argparse, itertools, json, math, time
from pathlib import Path
import numpy as np
from scipy.optimize import minimize

def threshold_exponent(m: int) -> float:
    return math.log2(1 + m / ((m - 1) ** 2 // 4))

class Problem:
    def __init__(self, m: int, eta: float):
        self.m = m; self.eta = eta; self.p = threshold_exponent(m)
        self.edges = list(itertools.combinations(range(m), 2)); self.idx = {e: i for i, e in enumerate(self.edges)}
        self.n = len(self.edges)
        # orthonormal basis of the zero-sum subspace
        Q, _ = np.linalg.qr(np.vstack([np.ones(m), np.eye(m)[: m - 1]]).T); self.Q = Q[:, 1:]
        self.triangles = list(itertools.combinations(range(m), 3)); self.quads = list(itertools.combinations(range(m), 4))
        k = m // 2
        self.types = [(k, k + 1)] if m % 2 else [(k - 1, k + 1), (k, k)]
    def mat(self, x):
        M = np.zeros((self.m, self.m))
        for k, (i, j) in enumerate(self.edges): M[i, j] = M[j, i] = x[k]
        return M
    def gap_and_grad(self, x):
        d = self.mat(x); E = d ** self.p; H = -self.Q.T @ E @ self.Q
        vals, vecs = np.linalg.eigh(H); z = self.Q @ vecs[:, 0]
        g = np.array([-2 * z[i] * z[j] * self.p * d[i, j] ** (self.p - 1) for i, j in self.edges])
        return vals[0], g, vals[1] - vals[0]
    def gap(self, x): return self.gap_and_grad(x)[0]
    def constraints(self):
        cons = []
        for (i, j, k) in self.triangles:
            for (u, v, wv) in [((i, j), (i, k), (j, k)), ((i, k), (i, j), (j, k)), ((j, k), (i, j), (i, k))]:
                a_, b_, c_ = self.idx[u], self.idx[v], self.idx[wv]
                cons.append({'type': 'ineq', 'fun': (lambda x, a_=a_, b_=b_, c_=c_: x[b_] + x[c_] - x[a_]),
                             'jac': (lambda x, a_=a_, b_=b_, c_=c_: self._lin(a_, b_, c_))})
        for (i, j, k, l) in self.quads:
            prods = [((i, j), (k, l)), ((i, k), (j, l)), ((i, l), (j, k))]
            for t in range(3):
                (u1, u2) = prods[t]; others = [prods[s] for s in range(3) if s != t]
                A = (self.idx[u1], self.idx[u2]); B = (self.idx[others[0][0]], self.idx[others[0][1]]); C = (self.idx[others[1][0]], self.idx[others[1][1]])
                cons.append({'type': 'ineq', 'fun': (lambda x, A=A, B=B, C=C: x[B[0]] * x[B[1]] + x[C[0]] * x[C[1]] - x[A[0]] * x[A[1]]),
                             'jac': (lambda x, A=A, B=B, C=C: self._ptol_jac(x, A, B, C))})
        return cons
    def _lin(self, a_, b_, c_):
        g = np.zeros(self.n); g[b_] += 1; g[c_] += 1; g[a_] -= 1; return g
    def _ptol_jac(self, x, A, B, C):
        g = np.zeros(self.n)
        g[B[0]] += x[B[1]]; g[B[1]] += x[B[0]]; g[C[0]] += x[C[1]]; g[C[1]] += x[C[0]]; g[A[0]] -= x[A[1]]; g[A[1]] -= x[A[0]]
        return g
    def violation(self, x):
        d = self.mat(x); v = 0.0
        for i, j, k in self.triangles:
            v = max(v, d[i, j] - d[i, k] - d[k, j], d[i, k] - d[i, j] - d[j, k], d[j, k] - d[i, j] - d[i, k])
        for i, j, k, l in self.quads:
            pr = [d[i, j] * d[k, l], d[i, k] * d[j, l], d[i, l] * d[j, k]]
            v = max(v, max(pr) - (sum(pr) - max(pr)))
        v = max(v, self.eta - x.min(), x.max() - 1.0)
        return v
    def split_vector(self, a, r, clique):
        x = np.zeros(self.n); cl = set(clique)
        for k, (i, j) in enumerate(self.edges): x[k] = 1.0 if (i in cl or j in cl) else 2.0
        return x
    def distance_to_splits(self, x):
        """min over type, labelling and scale of ||x/lambda - split||_inf, lambda = mean cross-distance."""
        best = (np.inf, None)
        for (a, r) in self.types:
            for clique in itertools.combinations(range(self.m), a):
                sv = self.split_vector(a, r, clique); cross = (sv == 1.0) & np.array([not (i in clique and j in clique) for i, j in self.edges])
                lam = x[cross].mean()
                dist = np.abs(x / lam - sv).max()
                if dist < best[0]: best = (dist, (a, r, clique, lam))
        return best
    def random_start(self, rng):
        mode = rng.integers(0, 3)
        for _ in range(1000):
            if mode == 0:   # random Euclidean configuration
                dim = int(rng.integers(2, 6)); P = rng.normal(size=(self.m, dim))
                d = np.array([np.linalg.norm(P[i] - P[j]) for i, j in self.edges])
            elif mode == 1:  # random snowflaked Euclidean configuration (still Ptolemaic)
                dim = int(rng.integers(2, 6)); P = rng.normal(size=(self.m, dim)); al = rng.uniform(0.5, 1.0)
                d = np.array([np.linalg.norm(P[i] - P[j]) ** al for i, j in self.edges])
            else:            # random perturbation of a random split copy
                a, r = self.types[rng.integers(0, len(self.types))]
                clique = tuple(sorted(rng.choice(self.m, a, replace=False)))
                d = self.split_vector(a, r, clique) * (1 + rng.uniform(-0.25, 0.25, self.n))
            d = d / d.max()
            if d.min() >= self.eta: return d

def run(m, eta, starts, seed, tol_gap, tol_dist):
    prob = Problem(m, eta); rng = np.random.default_rng(seed); cons = prob.constraints()
    bounds = [(eta, 1.0)] * prob.n
    records = []; t0 = time.time()
    for s in range(starts):
        x0 = prob.random_start(rng)
        res = minimize(lambda x: prob.gap_and_grad(x)[0], x0, jac=lambda x: prob.gap_and_grad(x)[1], method='SLSQP',
                       bounds=bounds, constraints=cons, options={'maxiter': 400, 'ftol': 1e-14})
        x = np.clip(res.x, eta, 1.0)
        g, _, eiggap = prob.gap_and_grad(x); viol = prob.violation(x); dist, info = prob.distance_to_splits(x)
        records.append({'start': s, 'gap': float(g), 'violation': float(viol), 'distance_to_nearest_split': float(dist),
                        'nearest_type': None if info is None else [info[0], info[1]], 'eigen_gap_above': float(eiggap),
                        'converged': bool(res.success), 'iterations': int(res.nit)})
    feasible = [r for r in records if r['violation'] < 1e-7]
    infeasible = [r for r in records if r['violation'] >= 1e-7]
    near_zero = [r for r in feasible if r['gap'] < tol_gap]
    positive = [r for r in feasible if r['gap'] >= tol_gap]
    ok = all(r['distance_to_nearest_split'] < tol_dist for r in near_zero)
    # a feasible point with a small but not tiny gap that is far from every split copy would be a
    # candidate for an unlisted equality metric; none is expected
    suspicious = [r for r in feasible if r['gap'] < 1e-4 and r['distance_to_nearest_split'] > 1e-2]
    summary = {'m': m, 'exponent': prob.p, 'eta': eta, 'starts': starts, 'seed': seed,
               'feasible_minima': len(feasible), 'infeasible_terminations': len(infeasible),
               'near_zero_minima': len(near_zero), 'all_near_zero_minima_are_split_copies': ok,
               'types_found': sorted({tuple(r['nearest_type']) for r in near_zero}, key=str),
               'max_distance_among_near_zero': max([r['distance_to_nearest_split'] for r in near_zero], default=None),
               'positive_feasible_minima': len(positive),
               'min_gap_among_positive_feasible_minima': min([r['gap'] for r in positive], default=None),
               'suspicious_small_gap_far_from_splits': len(suspicious),
               'elapsed_seconds': round(time.time() - t0, 1), 'tolerances': {'gap': tol_gap, 'distance': tol_dist},
               'caveat': 'Local optimisation from random starts; corroboration only, not exhaustive.'}
    return summary, records

if __name__ == '__main__':
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--output', type=Path, required=True); ap.add_argument('--starts', type=int, default=200)
    ap.add_argument('--seed', type=int, default=20260927); ap.add_argument('--eta', type=float, default=0.3)
    ap.add_argument('--sizes', type=int, nargs='+', default=[6, 7, 8])
    args = ap.parse_args(); args.output.mkdir(parents=True, exist_ok=True)
    out = {'status': 'PASS', 'scope': 'Numerical corroboration of the completeness of the equality classification.', 'groups': []}
    with open(args.output / 'equality_search_trials.jsonl', 'w') as fh:
        for m in args.sizes:
            summary, records = run(m, args.eta, args.starts, args.seed + m, 1e-7, 1e-3)
            out['groups'].append(summary); print(json.dumps(summary))
            for r in records: fh.write(json.dumps({'m': m, **r}) + '\n')
            if not summary['all_near_zero_minima_are_split_copies'] or summary['suspicious_small_gap_far_from_splits']: out['status'] = 'FAIL'
    (args.output / 'equality_search_results.json').write_text(json.dumps(out, indent=2, sort_keys=True) + '\n')
    print(out['status'])
