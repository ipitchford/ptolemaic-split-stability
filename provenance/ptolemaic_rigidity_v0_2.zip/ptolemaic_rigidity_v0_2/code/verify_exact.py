#!/usr/bin/env python3
"""Exact finite certificates for the rigidity and local-stability note, version 0.2.

Standard library only (fractions, itertools).  Finite checks are not a proof-assistant
verification of the universal classification.  The dual certificates checked here are the
finite input to the sharp seven-point stability constants; the rational inequality chain that
turns them into the displayed constants is also checked here.
"""
from __future__ import annotations
import argparse, json, sys
from fractions import Fraction as F
from itertools import combinations, permutations
from pathlib import Path
from random import Random

if sys.flags.optimize:
    raise SystemExit('Run without -O; this verifier uses assertions.')

# ----------------------------------------------------------------------------- linear algebra
def zeros(n, m): return [[F(0) for _ in range(m)] for _ in range(n)]
def eye(n):
    a = zeros(n, n)
    for i in range(n): a[i][i] = F(1)
    return a
def trans(a): return [list(x) for x in zip(*a)]
def mul(a, b):
    bt = trans(b)
    return [[sum((x * y for x, y in zip(row, col)), F(0)) for col in bt] for row in a]
def add(a, b): return [[x + y for x, y in zip(r, s)] for r, s in zip(a, b)]
def sub(a, b): return [[x - y for x, y in zip(r, s)] for r, s in zip(a, b)]
def scale(a, t): return [[t * x for x in r] for r in a]
def inv(a):
    n = len(a); b = [list(map(F, a[i])) + eye(n)[i] for i in range(n)]
    for j in range(n):
        k = next((i for i in range(j, n) if b[i][j]), None)
        if k is None: raise ValueError('Singular matrix')
        b[j], b[k] = b[k], b[j]
        q = b[j][j]; b[j] = [x / q for x in b[j]]
        for i in range(n):
            if i != j and b[i][j]:
                q = b[i][j]; b[i] = [x - q * y for x, y in zip(b[i], b[j])]
    return [r[n:] for r in b]
def rank(a):
    b = [list(map(F, r)) for r in a]; nr = len(b); nc = len(b[0]); i = 0
    for j in range(nc):
        k = next((k for k in range(i, nr) if b[k][j]), None)
        if k is None: continue
        b[i], b[k] = b[k], b[i]; q = b[i][j]; b[i] = [x / q for x in b[i]]
        for k in range(i + 1, nr):
            q = b[k][j]
            if q: b[k] = [x - q * y for x, y in zip(b[k], b[i])]
        i += 1
        if i == nr: break
    return i
def mv(a, x): return [sum((v * w for v, w in zip(r, x)), F(0)) for r in a]
def dot(x, y): return sum((a * b for a, b in zip(x, y)), F(0))
def quad(a, x): return dot(x, mv(a, x))
def outer(x, y): return [[a * b for b in y] for a in x]
def serial(x):
    if isinstance(x, F): return str(x)
    if isinstance(x, list): return [serial(z) for z in x]
    if isinstance(x, tuple): return [serial(z) for z in x]
    if isinstance(x, dict): return {str(k): serial(v) for k, v in x.items()}
    return x

# ----------------------------------------------------------------------------- metrics
def threshold(m): return 1 + F(m, (m - 1) ** 2 // 4)
def kn(n, T): return max(F(0), F(n - 1, n) * T - 1)
def Fpattern(a, r): return F((a + 1) * r, a * (r - 1))
def split(a, r, T=None):
    m = a + r; t = F(2) if T is None else T
    return [[F(0) if i == j else (t if i >= a and j >= a else F(1)) for j in range(m)] for i in range(m)]
def invert_metric(d, p):
    n = len(d); e = zeros(n, n)
    for i, j in combinations(range(n), 2):
        if i == p: v = 1 / d[p][j]
        elif j == p: v = 1 / d[p][i]
        else: v = d[i][j] / (d[p][i] * d[p][j])
        e[i][j] = e[j][i] = v
    return e
def metric_checks(d, strict=False):
    """Assert metric and Ptolemy inequalities; return (#triangle, #Ptolemy) inequalities checked."""
    n = len(d); nt = np_ = 0
    for i, j, k in combinations(range(n), 3):
        x, y, z = d[i][j], d[i][k], d[j][k]
        assert min(x + y - z, x + z - y, y + z - x) >= 0; nt += 3
    for i, j, k, l in combinations(range(n), 4):
        x = d[i][j] * d[k][l]; y = d[i][k] * d[j][l]; z = d[i][l] * d[j][k]
        assert min(x + y - z, x + z - y, y + z - x) >= 0; np_ += 3
    return nt, np_

# ----------------------------------------------------------------------------- active constraints of CS(3,4)
A_SET, B_SET = (0, 1, 2), (3, 4, 5, 6)
def active_matrix(a=3, r=4):
    m = a + r; edges = list(combinations(range(m), 2)); index = {x: i for i, x in enumerate(edges)}
    def row(terms):
        out = [F(0)] * len(edges)
        for i, j, v in terms: out[index[tuple(sorted((i, j)))]] += F(v)
        return out
    rows = []; names = []
    for i in range(a):
        for b, c in combinations(range(a, m), 2):
            rows.append(row([(i, b, 1), (i, c, 1), (b, c, -1)])); names.append(('tri', i, b, c))
    for i, j in combinations(range(a), 2):
        for b, c in combinations(range(a, m), 2):
            rows.append(row([(i, b, 1), (i, c, 1), (j, b, 1), (j, c, 1), (i, j, -2), (b, c, -1)])); names.append(('ptol', i, j, b, c))
    w = [F(int(i < a <= j)) for i, j in edges]
    s = [F(2 if i >= a else 1) for i, j in edges]
    return edges, rows, w, s, names

# Table 1 of the note: symmetrised dual certificates, given as rules on the row names.
def cert_anchor(sign):
    vals = {+1: (F(5, 6), F(13, 12), F(5, 4), F(1)), -1: (F(7, 6), F(11, 12), F(3, 4), F(1))}[sign]
    def eta(name):
        if name[0] == 'tri': return vals[0] if name[1] in (0, 1) else vals[1]
        return vals[2] if {name[1], name[2]} == {0, 1} else vals[3]
    return eta, {+1: F(-1, 4), -1: F(1, 4)}[sign]
def cert_cross(sign):
    vals = {+1: (F(5, 6), F(5, 6), F(35, 24), F(17, 24), F(5, 8), F(11, 8), F(1), F(1)),
            -1: (F(7, 6), F(7, 6), F(13, 24), F(31, 24), F(11, 8), F(5, 8), F(1), F(1))}[sign]
    def eta(name):
        if name[0] == 'tri':
            has0 = name[1] == 0; has3 = 3 in (name[2], name[3])
            return vals[0 if (has0 and has3) else 1 if has0 else 2 if has3 else 3]
        has0 = 0 in (name[1], name[2]); has3 = 3 in (name[3], name[4])
        return vals[4 if (has0 and has3) else 5 if has0 else 6 if has3 else 7]
    return eta, {+1: F(-1, 4), -1: F(1, 4)}[sign]
def cert_pole(sign):
    vals = {+1: (F(2), F(5, 4), F(0), F(1), F(3, 4), F(2)), -1: (F(0), F(3, 4), F(2), F(1), F(5, 4), F(0))}[sign]
    def eta(name):
        bc = {name[-2], name[-1]}; k = len(bc & {3, 4}); off = 0 if name[0] == 'tri' else 3
        return vals[off + (0 if k == 2 else 1 if k == 1 else 2)]
    return eta, {+1: F(-1, 2), -1: F(1, 2)}[sign]
REPRESENTATIVES = {(0, 1): cert_anchor, (0, 3): cert_cross, (3, 4): cert_pole}

def part_permutations():
    for pa in permutations(A_SET):
        for pb in permutations(B_SET):
            yield dict(zip(A_SET, pa)) | dict(zip(B_SET, pb))
def relabel_name(name, pi):
    if name[0] == 'tri':
        b, c = sorted((pi[name[2]], pi[name[3]])); return ('tri', pi[name[1]], b, c)
    i, j = sorted((pi[name[1]], pi[name[2]])); b, c = sorted((pi[name[3]], pi[name[4]])); return ('ptol', i, j, b, c)

def local_certificates():
    edges, D, w, s, names = active_matrix(); ne = len(edges); nr = len(D)
    assert nr == 36 and ne == 21 and rank(D) == 20 and mv(D, s) == [F(0)] * nr
    Dt = trans(D)
    # ell = 1^T D e  equals  9 sum x - 12 sum y - 6 sum t
    colsum = [sum(row[j] for row in D) for j in range(ne)]
    assert colsum == [F(9) if (i < 3 <= j) else F(-12) if j < 3 else F(-6) for i, j in edges]
    name_index = {n: i for i, n in enumerate(names)}
    summary = {}; verified = 0; max_ptolemy_weight = F(0)
    for rep_edge, maker in REPRESENTATIVES.items():
        for sign in (+1, -1):
            eta_rule, mu = maker(sign)
            eta = [eta_rule(n) for n in names]
            assert all(v >= 0 for v in eta)
            Yp = sum(eta[i] for i, n in enumerate(names) if n[0] == 'ptol')
            max_ptolemy_weight = max(max_ptolemy_weight, Yp)
            # verify for every image edge under the symmetry group of the split
            seen = set()
            for pi in part_permutations():
                target = tuple(sorted((pi[rep_edge[0]], pi[rep_edge[1]])))
                if target in seen: continue
                seen.add(target); k = edges.index(target)
                eta_t = [F(0)] * nr
                for i, n in enumerate(names): eta_t[name_index[relabel_name(n, pi)]] = eta[i]
                lhs = mv(Dt, [1 - v for v in eta_t])
                rhs = [mu * w[j] + (3 * sign if j == k else 0) for j in range(ne)]
                assert lhs == rhs, (rep_edge, sign, target)
                verified += 1
            summary[f'{rep_edge}/{sign:+d}'] = {'mu': mu, 'ptolemy_weight': Yp, 'image_edges_verified': len(seen)}
    assert verified == 42 and max_ptolemy_weight == F(39, 2)
    # primal extremal directions
    index = {x: i for i, x in enumerate(edges)}
    e0 = [F(0)] * ne
    for a_ in A_SET:
        e0[index[(a_, 3)]] = e0[index[(a_, 4)]] = F(-1, 4); e0[index[(a_, 5)]] = e0[index[(a_, 6)]] = F(1, 4)
    e0[index[(3, 4)]] = F(-1); e0[index[(5, 6)]] = F(1, 2)
    e1 = [F(-1) if (w[j] == 0) else F(0) for j in range(ne)]
    De0 = mv(D, e0); De1 = mv(D, e1)
    assert min(De0) >= 0 and sum(De0) == 3 and dot(w, e0) == 0 and max(abs(v) for v in e0) == 1
    assert min(De1) >= 1 and sum(De1) == 72 and dot(w, e1) == 0
    # version 0.1 left-inverse certificate, kept for comparison: gives 9/4 in place of 3
    H = add(mul(Dt, D), outer(w, w)); L = mul(inv(H), Dt)
    assert mul(L, D) == sub(eye(ne), scale(outer(s, w), F(1, 12)))
    assert max(abs(x) for row in L for x in row) == F(4, 9)
    # sharp families are Ptolemaic at dyadic h, with the stated shrinkage and deviation
    fam = []
    for j in range(5, 15):
        h = F(1, 2 ** j)
        dvec = [s[t] + h * e0[t] + h * h * e1[t] for t in range(ne)]
        d = zeros(7, 7)
        for t, (i, k) in enumerate(edges): d[i][k] = d[k][i] = dvec[t]
        metric_checks(d)
        ell = -12 * sum(dvec[t] - 1 for t, (i, k) in enumerate(edges) if k < 3) - 6 * sum(dvec[t] - 2 for t, (i, k) in enumerate(edges) if i >= 3)
        dev = max(abs(dvec[t] - s[t]) for t in range(ne))
        assert ell == 3 * h + 72 * h * h and dev == h + h * h and sum(dvec[t] for t in range(ne) if w[t]) == 12
        d2 = zeros(7, 7)
        for t, (i, k) in enumerate(edges): d2[i][k] = d2[k][i] = s[t] + h * e1[t]
        metric_checks(d2)
        fam.append({'h': h, 'shrinkage': ell, 'deviation': dev})
    return {'rows': nr, 'edges': ne, 'rank_D': 20, 'certificates': summary, 'certificates_verified_all_edges_and_signs': verified,
            'max_ptolemy_weight': max_ptolemy_weight, 'primal_min_direction_shrinkage': F(3), 'primal_max_direction_shrinkage': F(72),
            'v01_left_inverse_max_entry': F(4, 9), 'sharp_family_checks': fam, 'constraint_rows': names, 'D': D, 'w': w, 's': s,
            'e0': e0, 'e1': e1}

# ----------------------------------------------------------------------------- rational constant chain
def constant_chain():
    """Certify the numerical constants of Section 8 with integer and rational arithmetic."""
    plo, phi = F(83, 100), F(8301, 10000)
    assert 2 ** 83 * 9 ** 100 < 16 ** 100            # p_* > 0.83
    assert 16 ** 10000 < 2 ** 8301 * 9 ** 10000      # p_* < 0.8301
    assert F(2634, 100000) < 2 * plo / 63 and 2 * phi / 63 < F(2636, 100000)
    theta = F(10119, 10000)                          # (100/99)^{1.17} <= theta
    assert 100 ** 117 * 10000 ** 100 <= 99 ** 117 * 10119 ** 100
    q2 = F(1, 2) * phi * (1 - plo) * theta          # >= (1/2) p(1-p) (1-h)^{p-2} for h<=1/100
    assert phi * (1 - plo) < F(1412, 10000) and q2 <= F(715, 10000)
    c_taylor = 6 * F(715, 10000); assert c_taylor <= F(429, 1000)            # ||H-H_lin|| <= 0.429 h^2
    c_quad = F(41, 7) * F(715, 10000); assert c_quad <= F(419, 1000)         # |z*(H-H_lin)z*| <= 0.419 h^2
    c_lin = 6 * phi; assert c_lin <= F(49806, 10000)                          # ||H_lin|| <= 4.9806 h
    h0 = F(1, 100)
    eps = F(49806, 10000) + F(429, 1000) * h0; assert eps <= F(4985, 1000)    # ||H|| <= 4.985 h
    assert eps * h0 <= F(1, 20) and 1 - 2 * eps * h0 >= F(9003, 10000)
    assert (10 * phi) ** 2 <= 3 * F(47926, 10000) ** 2                         # 10p/sqrt3 <= 4.7926
    bnorm = F(47926, 10000) + F(429, 1000) * h0; assert bnorm <= F(4797, 1000)
    assert F(4797, 1000) ** 2 <= F(2302, 100)
    schur = F(2302, 100) / F(9003, 10000); assert schur <= F(2557, 100)
    assert schur + F(419, 1000) <= 26                                          # first-order law lower constant
    assert F(4797, 1000) / F(9003, 10000) <= F(533, 100) <= 6                  # eigenvector bound
    assert 2 * phi / 63 * F(117, 2) <= F(1542, 1000) and 26 + F(1542, 1000) <= 28
    assert 2 * phi / 63 * 72 == 16 * phi / 7
    h1 = F(1, 1000)
    assert 2 * plo / 21 - 28 * h1 > F(1, 20) and 16 * phi / 7 + h1 / 2 < 2
    assert 2 * plo / 21 > F(7904, 100000) and 16 * phi / 7 < F(18974, 10000)
    # v0.1 comparison: p/14 < 2p/21 and 8p/7 lies strictly between the two sharp constants
    assert plo / 14 < 2 * plo / 21 and 2 * phi / 21 < 8 * plo / 7 < 16 * plo / 7
    return {'p_lower': plo, 'p_upper': phi, 'theta': theta, 'q2_upper': F(715, 10000), 'law_lower_constant': 26,
            'combined_lower_constant': 28, 'clean_radius': h1, 'clean_lower': F(1, 20), 'clean_upper': 2}

# ----------------------------------------------------------------------------- main
def main(output):
    output.mkdir(parents=True, exist_ok=True)
    result = {'status': 'PASS', 'version': '0.2', 'scope': 'Finite exact identities, certificates and witnesses; the analytic proofs are in the note.',
              'proof_assistant_used': False, 'groups': {}}
    cert = local_certificates()
    (output / 'local_stability_certificate.json').write_text(json.dumps(serial(cert), indent=2, sort_keys=True) + '\n')
    result['groups']['local_certificate'] = {k: serial(v) for k, v in cert.items() if k not in ('constraint_rows', 'D', 'w', 's', 'e0', 'e1')}
    result['groups']['constant_chain'] = serial(constant_chain())
    # parameter cases, now from m = 6
    cnt = 0; cases = []
    for m in range(6, 301):
        T = threshold(m); assert 1 < T <= 2 and (T < 2) == (m > 6)
        possible = [a for a in range(1, m // 2 + 1) if a * (m - 1 - a) == (m - 1) ** 2 // 4]
        k = m // 2
        assert possible == ([k] if m % 2 else [k - 1, k])
        for a in possible:
            r = m - a; n = a + 1
            assert Fpattern(a, r) == T and kn(n, T) == F(1, r - 1) > 0
            strict = T < F(n, n - 2)
            assert strict == (a < r)                      # strict slack exactly in the unbalanced patterns
            if strict: assert kn(n - 1, T) < kn(n, T) / (1 + kn(n, T)) < kn(n, T)
            # two-simplex identity: rho_A^2 + rho_B^2 = 1 exactly at the binding split
            rhoA2 = F(a - 1, 2 * a); rhoB2 = T * F(r - 1, 2 * r)
            assert rhoA2 + rhoB2 == 1
        # non-binding splits have positive centre separation at T_m
        for a in range(2, m // 2 + 1):
            if a in possible: continue
            r = m - a; assert 1 - F(a - 1, 2 * a) - T * F(r - 1, 2 * r) > 0 and T < Fpattern(a, r)
        cnt += 1
    result['groups']['parameter_cases'] = {'cardinalities': cnt, 'range': [6, 300]}
    witnesses = []; triangles = ptolemy = inversions = transport = 0; rng = Random(271828)
    for m in range(6, 19):
        k = m // 2
        for a in ([k] if m % 2 else [k - 1, k]):
            r = m - a; T = threshold(m); d = split(a, r); E = split(a, r, T)
            nt, np_ = metric_checks(d); triangles += nt; ptolemy += np_
            z = [F(1, a)] * a + [F(-1, r)] * r
            assert sum(z) == 0 and quad(E, z) == 0
            assert mv(E, z) == [F(-1, a)] * m
            Pi = sub(eye(m), scale([[F(1)] * m for _ in range(m)], F(1, m)))
            G = scale(mul(mul(Pi, E), Pi), F(-1, 2))
            assert mv(G, [F(1)] * m) == [F(0)] * m and mv(G, z) == [F(0)] * m
            for indices, ev in [(range(a), F(1, 2)), (range(a, m), T / 2)]:
                indices = list(indices)
                for j in indices[1:]:
                    q = [F(0)] * m; q[indices[0]] = 1; q[j] = -1
                    assert mv(G, q) == [ev * x for x in q]
            assert rank(G) == m - 2
            for p in range(m):
                dh = invert_metric(d, p); Eh = invert_metric(E, p)
                assert invert_metric(dh, p) == d and invert_metric(Eh, p) == E
                if p < a:
                    cl = set(range(a)); sc = F(1); scp = F(1)
                else:
                    cl = set(range(a, m)) - {p}; sc = F(1, 2); scp = 1 / T
                for i, j in combinations(range(m), 2):
                    assert dh[i][j] == sc * (1 if i in cl or j in cl else 2)
                    assert Eh[i][j] == scp * (1 if i in cl or j in cl else T)
                inversions += 1
                c = [F(rng.randrange(-5, 6)) for _ in range(m - 1)]; c.append(-sum(c))
                ch = [c[j] * E[p][j] if j != p else F(0) for j in range(m)]
                ch[p] = -sum(ch)
                assert sum(ch) == 0 and quad(Eh, ch) == quad(E, c); transport += 1
                # transport of the equality vector: infinity coefficient is -lambda = 1/a, sign pattern shifts as stated
                zh = [z[j] * E[p][j] if j != p else F(0) for j in range(m)]; zh[p] = -F(-1, a)
                assert sum(zh) == 0 and quad(Eh, zh) == 0
                pos = sum(1 for v in zh if v > 0); neg = sum(1 for v in zh if v < 0)
                assert (pos, neg) == ((a + 1, r - 1) if p >= a else (a, r))
                # and it is proportional to the standard equality vector of the inverted split
                if p >= a:
                    zs = [F(-1, a + 1) if (j < a or j == p) else F(1, r - 1) for j in range(m)]
                else:
                    zs = [F(1, a) if j < a else F(-1, r) for j in range(m)]
                ratio = None
                for j in range(m):
                    assert zs[j] != 0
                    q = zh[j] / zs[j]; ratio = q if ratio is None else ratio
                    assert q == ratio
            witnesses.append({'m': m, 'clique': a, 'independent': r, 'T': T, 'gram_rank': m - 2, 'lambda': F(-1, a)})
    result['groups']['split_witnesses'] = {'cases': len(witnesses), 'triangles': triangles, 'ptolemy': ptolemy,
                                           'all_vertex_inversions': inversions, 'generic_transports': transport, 'witnesses': serial(witnesses)}
    # Five-point equality and star regauging at T=16/9, and the six-point analogue CS(2,2) at T=2.
    pairs = {}
    for (a, T, label) in [(3, F(16, 9), 'seven'), (2, F(2), 'six')]:
        E = split(a, 2, T); d = split(a, 2); n = a + 2; A = zeros(n + 1, n + 1)
        for i in range(n): A[0][i + 1] = A[i + 1][0] = 1
        for i in range(n):
            for j in range(n): A[i + 1][j + 1] = E[i][j]
        V = inv(A); assert V[n - 1][n - 1] == V[n][n] < 0
        rho = V[n - 1][n] / (-V[n - 1][n - 1]); assert rho == -kn(a + 1, T) == F(-1, 3)
        assert all(V[n - 1][j] > 0 and V[n][j] > 0 for j in range(n - 1))
        # invert at pole a: the result is an equal-arm star centred at pole a+1 with arm 1/2,
        # whose leaves are the anchors 0..a-1 and the new infinity point (index a)
        dh = invert_metric(d, a); centre = a + 1; leaves = list(range(a)) + [a]
        assert all(dh[centre][x] == F(1, 2) for x in leaves)
        assert all(dh[x][y] == 1 for x, y in combinations(leaves, 2))
        pairs[label] = {'anchors': a, 'T': T, 'rho': rho, 'star_arm': F(1, 2)}
    result['groups']['anchor_pole_pair_equality'] = serial(pairs)
    # Endpoint p=1 inputs (Lemma 6.1): random rational three- and four-point metrics
    rng2 = Random(31415); checks = {'three_point_uv_nonnegative': 0, 'four_point_packing_M_le_n': 0, 'four_point_u_or_v_signed': 0}
    for _ in range(400):
        pts = sorted(F(rng2.randrange(0, 200), 7) for _ in range(3))
        r1, r2 = pts[1] - pts[0], pts[2] - pts[0]; d12 = pts[2] - pts[1]           # collinear: tight triangle inequalities
        if rng2.random() < 0.5:
            d12 = F(rng2.randrange(int(abs(r1 - r2) * 7), int((r1 + r2) * 7) + 1), 7)
        if not (r1 > 0 and r2 > 0 and d12 > 0): continue
        sig = (r1 + r2 - d12) / 2; C = [[r1, sig], [sig, r2]]
        if r1 * r2 - sig * sig <= 0: continue
        Ci = inv(C); u = mv(Ci, [r1, r2]); v = mv(Ci, [F(1), F(1)])
        assert min(u) >= 0 and min(v) >= 0; checks['three_point_uv_nonnegative'] += 1
    for _ in range(400):
        # random four-point Euclidean-like rational metric via random points on a line plus perturbation, then check Ptolemy
        pts = [F(rng2.randrange(0, 100), 9) for _ in range(4)]
        d = [[abs(pts[i] - pts[j]) for j in range(4)] for i in range(4)]
        if any(d[i][j] == 0 for i, j in combinations(range(4), 2)): continue
        r = [d[0][i] for i in range(1, 4)]
        C = [[(r[i - 1] + r[j - 1] - d[i][j]) / 2 for j in range(1, 4)] for i in range(1, 4)]
        try: Ci = inv(C)
        except ValueError: continue
        u = mv(Ci, r); v = mv(Ci, [F(1)] * 3); M = dot(r, v)
        assert M == sum(u)
        if min(v) >= 0 or min(u) >= 0:
            assert M <= 3; checks['four_point_packing_M_le_n'] += 1
        checks['four_point_u_or_v_signed'] += 1
    result['groups']['endpoint_one_inputs'] = checks
    line_cases = []
    for j in range(3, 14):
        pts = [F(0), F(5, 2 ** j), F(1), F(2), F(3), F(4), F(5)]
        d = [[abs(x - y) / 5 for y in pts] for x in pts]
        metric_checks(d)
        ray = F(16, 9) ** (-j); dist = F(1, 2) - F(1, 2 ** j)
        assert d[0][1] == F(1, 2 ** j)
        line_cases.append({'j': j, 'rayleigh_upper_bound': str(ray), 'distance_lower_bound': str(dist)})
    result['groups']['collision_examples'] = line_cases
    (output / 'exact_results.json').write_text(json.dumps(result, indent=2, sort_keys=True) + '\n')
    print(json.dumps({'status': 'PASS', 'groups': len(result['groups']), 'witnesses': len(witnesses),
                      'certificates_verified': cert['certificates_verified_all_edges_and_signs'], 'output': str(output)}, indent=2))

if __name__ == '__main__':
    ap = argparse.ArgumentParser(description=__doc__); ap.add_argument('--output', type=Path, required=True)
    main(ap.parse_args().output)
