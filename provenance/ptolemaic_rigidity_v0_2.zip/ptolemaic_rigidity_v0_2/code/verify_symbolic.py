#!/usr/bin/env python3
"""Independent symbolic reconstruction (SymPy) of the finite identities used in the note, v0.2.

This script does not import verify_exact.py.  It rebuilds the active-constraint matrix by
differentiating the metric and Ptolemy inequalities, re-derives the symmetrised dual certificates
as the solution families of the reduced linear systems, and checks the derivative, spectral,
Taylor and geometric identities symbolically.  Identity checks are not a proof of the analytic
statements.
"""
from __future__ import annotations
import argparse, json, sys
from itertools import combinations, permutations
from pathlib import Path
import sympy as sp

if sys.flags.optimize:
    raise SystemExit('Run without -O.')

R = sp.Rational
A_SET, B_SET = (0, 1, 2), (3, 4, 5, 6); M7 = 7
EDGES = list(combinations(range(M7), 2)); IDX = {e: i for i, e in enumerate(EDGES)}
X = sp.symbols('x0:21')                      # edge perturbations e = d - s
S = [2 if i >= 3 else 1 for i, j in EDGES]  # split distances
D_SYM = {e: S[k] + X[k] for k, e in enumerate(EDGES)}
def dsym(i, j): return D_SYM[tuple(sorted((i, j)))]

def reconstruct_active_matrix():
    """All triangle and Ptolemy constraints of a 7-point metric, linearised at s; keep the active ones."""
    rows = []; names = []; count_all = 0
    for i, j, k in combinations(range(M7), 3):
        for (u, v, w) in [((i, j), (i, k), (j, k)), ((i, k), (i, j), (j, k)), ((j, k), (i, j), (i, k))]:
            slack = dsym(*v) + dsym(*w) - dsym(*u); count_all += 1
            if slack.subs({x: 0 for x in X}) == 0:
                rows.append([sp.diff(slack, x) for x in X]); names.append(('tri',) + (u, v, w))
    for i, j, k, l in combinations(range(M7), 4):
        prods = [((i, j), (k, l)), ((i, k), (j, l)), ((i, l), (j, k))]
        for t in range(3):
            (u1, u2) = prods[t]; others = [prods[s_] for s_ in range(3) if s_ != t]
            slack = dsym(*others[0][0]) * dsym(*others[0][1]) + dsym(*others[1][0]) * dsym(*others[1][1]) - dsym(*u1) * dsym(*u2)
            count_all += 1
            if slack.subs({x: 0 for x in X}) == 0:
                grad = [sp.diff(slack, x).subs({y: 0 for y in X}) for x in X]
                quad = sp.expand(slack - sum(g * x for g, x in zip(grad, X)))
                rows.append(grad); names.append(('ptol', u1, u2, quad))
    return rows, names, count_all

def canonical_name(n):
    if n[0] == 'tri':
        (b, c) = n[1]; a = (set(n[2]) & set(n[3])).pop(); return ('tri', a, min(b, c), max(b, c))
    (u1, u2) = n[1], n[2]
    aa = tuple(sorted(u1 if u1[0] < 3 and u1[1] < 3 else u2)); bc = tuple(sorted(u2 if aa == tuple(sorted(u1)) else u1))
    return ('ptol', aa[0], aa[1], bc[0], bc[1])

def main(output):
    output.mkdir(parents=True, exist_ok=True)
    res = {'status': 'PASS', 'version': '0.2', 'proof_assistant_used': False, 'groups': {}}
    rows, names, count_all = reconstruct_active_matrix()
    D = sp.Matrix(rows); assert D.shape == (36, 21) and count_all == 3 * 35 + 3 * 35 and D.rank() == 20
    svec = sp.Matrix(S); assert (D * svec).is_zero_matrix
    w = sp.Matrix([1 if i < 3 <= j else 0 for i, j in EDGES])
    cnames = [canonical_name(n) for n in names]
    tri_rows = [i for i, n in enumerate(cnames) if n[0] == 'tri']; pt_rows = [i for i, n in enumerate(cnames) if n[0] == 'ptol']
    assert len(tri_rows) == 18 and len(pt_rows) == 18
    # quadratic Ptolemy remainder is x_ab x_a'c + x_ac x_a'b - y t, three monomials of degree two
    for i in pt_rows:
        quad = names[i][3]; assert len(quad.as_ordered_terms()) == 3 and sp.Poly(quad, *X).total_degree() == 2
    # ell = 1^T D e
    colsum = list(sp.ones(1, 36) * D)
    assert colsum == [9 if (i < 3 <= j) else -12 if j < 3 else -6 for i, j in EDGES]
    res['groups']['active_matrix'] = {'total_inequalities_scanned': count_all, 'active': 36, 'rank': 20, 'kernel': 'R s'}

    # ---- symmetrised dual certificates as exact solution families
    cidx = {n: i for i, n in enumerate(cnames)}
    def relabel(n, pi):
        if n[0] == 'tri':
            b, c = sorted((pi[n[2]], pi[n[3]])); return ('tri', pi[n[1]], b, c)
        a1, a2 = sorted((pi[n[1]], pi[n[2]])); b, c = sorted((pi[n[3]], pi[n[4]])); return ('ptol', a1, a2, b, c)
    def stabiliser(edge):
        G = []
        for pa in permutations(A_SET):
            for pb in permutations(B_SET):
                pi = dict(zip(A_SET, pa)) | dict(zip(B_SET, pb))
                if tuple(sorted((pi[edge[0]], pi[edge[1]]))) == edge: G.append(pi)
        return G
    table = {  # Table 1 of the note, by orbit representative
        (0, 1): {+1: (R(-1, 4), {('tri', 0, 3, 4): R(5, 6), ('tri', 2, 3, 4): R(13, 12), ('ptol', 0, 1, 3, 4): R(5, 4), ('ptol', 0, 2, 3, 4): 1}),
                 -1: (R(1, 4), {('tri', 0, 3, 4): R(7, 6), ('tri', 2, 3, 4): R(11, 12), ('ptol', 0, 1, 3, 4): R(3, 4), ('ptol', 0, 2, 3, 4): 1})},
        (0, 3): {+1: (R(-1, 4), {('tri', 0, 3, 4): R(5, 6), ('tri', 0, 4, 5): R(5, 6), ('tri', 1, 3, 4): R(35, 24), ('tri', 1, 4, 5): R(17, 24),
                                 ('ptol', 0, 1, 3, 4): R(5, 8), ('ptol', 0, 1, 4, 5): R(11, 8), ('ptol', 1, 2, 3, 4): 1, ('ptol', 1, 2, 4, 5): 1}),
                 -1: (R(1, 4), {('tri', 0, 3, 4): R(7, 6), ('tri', 0, 4, 5): R(7, 6), ('tri', 1, 3, 4): R(13, 24), ('tri', 1, 4, 5): R(31, 24),
                                ('ptol', 0, 1, 3, 4): R(11, 8), ('ptol', 0, 1, 4, 5): R(5, 8), ('ptol', 1, 2, 3, 4): 1, ('ptol', 1, 2, 4, 5): 1})},
        (3, 4): {+1: (R(-1, 2), {('tri', 0, 3, 4): 2, ('tri', 0, 3, 5): R(5, 4), ('tri', 0, 5, 6): 0, ('ptol', 0, 1, 3, 4): 1, ('ptol', 0, 1, 3, 5): R(3, 4), ('ptol', 0, 1, 5, 6): 2}),
                 -1: (R(1, 2), {('tri', 0, 3, 4): 0, ('tri', 0, 3, 5): R(3, 4), ('tri', 0, 5, 6): 2, ('ptol', 0, 1, 3, 4): 1, ('ptol', 0, 1, 3, 5): R(5, 4), ('ptol', 0, 1, 5, 6): 0})},
    }
    cert_report = {}
    for edge, per_sign in table.items():
        G = stabiliser(edge); k = IDX[edge]
        # orbits of rows under the stabiliser
        orbit_of = {}; reps = []
        for n in cnames:
            if n in orbit_of: continue
            orb = {relabel(n, pi) for pi in G}
            for o in orb: orbit_of[o] = len(reps)
            reps.append(n)
        for sign, (mu_table, values) in per_sign.items():
            Y = sp.symbols(f'eta0:{len(reps)}'); mu = sp.Symbol('mu')
            eta_full = sp.Matrix([Y[orbit_of[n]] for n in cnames])
            eqs = list(D.T * (sp.ones(36, 1) - eta_full) - mu * w - 3 * sign * sp.Matrix([1 if t == k else 0 for t in range(21)]))
            sol = sp.linsolve(eqs, list(Y) + [mu]); (sol,) = list(sol)
            free = sorted(sol.free_symbols, key=str); assert len(free) <= 1
            # the table values must be a point of the family with eta >= 0 and the stated mu
            subs = {}
            if free:
                # find the parameter value from any orbit whose table value pins it
                for r_i, rep in enumerate(reps):
                    expr = sol[r_i]
                    if expr.has(free[0]):
                        val = sp.solve(sp.Eq(expr, values[rep]), free[0]); assert len(val) == 1; subs = {free[0]: val[0]}; break
            for r_i, rep in enumerate(reps):
                assert sp.simplify(sol[r_i].subs(subs) - values[rep]) == 0, (edge, sign, rep)
                assert values[rep] >= 0
            assert sp.simplify(sol[-1].subs(subs) - mu_table) == 0
            Yp = sum(values[rep] * sum(1 for n in cnames if orbit_of[n] == r_i) for r_i, rep in enumerate(reps) if rep[0] == 'ptol')
            cert_report[f'{edge}/{sign:+d}'] = {'orbits': len(reps), 'free_parameters': len(free), 'ptolemy_weight': str(Yp),
                                                'ptolemy_weight_constant_on_family': str(sp.simplify(sum(sol[r_i] * sum(1 for n in cnames if orbit_of[n] == r_i) for r_i, rep in enumerate(reps) if rep[0] == 'ptol')))}
    assert cert_report['(0, 1)/+1']['ptolemy_weight'] == '39/2' and cert_report['(0, 1)/-1']['ptolemy_weight'] == '33/2'
    assert all(cert_report[key]['ptolemy_weight'] == '18' for key in cert_report if not key.startswith('(0, 1)'))
    res['groups']['dual_certificates'] = cert_report

    # ---- derivative along z_* and the general first variation
    p = sp.Symbol('p', positive=True)
    zstar = sp.Matrix([4, 4, 4, -3, -3, -3, -3]) / sp.sqrt(84)
    Q = sp.zeros(M7, M7)
    for k, (i, j) in enumerate(EDGES): Q[i, j] = Q[j, i] = -(S[k] ** (p - 1)) * X[k]   # H_lin entrywise, up to the factor p
    deriv = sp.expand((zstar.T * Q * zstar)[0] * p)
    xs = [X[IDX[e]] for e in EDGES if e[0] < 3 <= e[1]]; ys = [X[IDX[e]] for e in EDGES if e[1] < 3]; ts = [X[IDX[e]] for e in EDGES if e[0] >= 3]
    ell = -12 * sum(ys) - 6 * sum(ts)
    T7 = R(16, 9)
    diff_ = sp.simplify(deriv.subs(p, sp.log(T7, 2)) - (2 * sp.log(T7, 2) / 63) * ell - (2 * sp.log(T7, 2) / 7) * sum(xs))
    assert diff_ == 0
    general = {}
    for (a, r) in [(2, 4), (3, 3), (3, 4), (3, 5), (4, 4), (4, 5), (5, 6)]:
        m = a + r; T = R((a + 1) * r, a * (r - 1)); pm = sp.log(T, 2)
        z = sp.Matrix([R(1, a)] * a + [R(-1, r)] * r); z = z / sp.sqrt((z.T * z)[0])
        edges = list(combinations(range(m), 2)); xv = sp.symbols(f'v0:{len(edges)}')
        Hl = sp.zeros(m, m)
        for k, (i, j) in enumerate(edges):
            sk = 2 if i >= a else 1; Hl[i, j] = Hl[j, i] = -pm * sk ** (pm - 1) * xv[k]
        d1 = sp.expand((z.T * Hl * z)[0])
        ys_ = [xv[k] for k, (i, j) in enumerate(edges) if j < a]; ts_ = [xv[k] for k, (i, j) in enumerate(edges) if i >= a]
        xs_ = [xv[k] for k, (i, j) in enumerate(edges) if i < a <= j]
        predicted = (2 * pm / m) * (R(r, a) * sum(-y for y in ys_) + (a * T / (2 * r)) * sum(-t for t in ts_)) + (2 * pm / m) * sum(xs_)
        assert sp.simplify(d1 - predicted) == 0
        general[f'({a},{r})'] = str(sp.nsimplify(2 * pm / m * R(r, a) / pm))
    res['groups']['first_variation'] = {'seven_point_coefficient': '2p/63 times shrinkage', 'general_cases_checked': general}

    # ---- reference spectrum and centred Gram at seven points
    E = sp.zeros(M7, M7)
    for k, (i, j) in enumerate(EDGES): E[i, j] = E[j, i] = T7 if S[k] == 2 else 1
    Pi = sp.eye(M7) - sp.ones(M7, M7) / 7
    G = -Pi * E * Pi / 2
    ev = G.eigenvals(); assert ev == {R(1, 2): 2, R(8, 9): 3, 0: 2}
    Gexp = sp.diag(R(1, 2) * (sp.eye(3) - sp.ones(3, 3) / 3), R(8, 9) * (sp.eye(4) - sp.ones(4, 4) / 4))
    assert G == Gexp and (G * zstar).is_zero_matrix and (G * sp.ones(7, 1)).is_zero_matrix
    # restricted spectrum of -Pi E Pi on 1-perp: 0,1,1,16/9 x3
    Qb = sp.Matrix.hstack(*[v for v in sp.Matrix.hstack(sp.ones(7, 1), sp.eye(7)[:, :6]).QRdecomposition()[0][:, 1:].columnspace()])
    Hr = -Qb.T * E * Qb
    assert sp.simplify(Hr).eigenvals() == {0: 1, 1: 2, T7: 3}
    res['groups']['reference_spectrum'] = {'centred_gram_eigenvalues': '1/2 x2, 8/9 x3, 0 x2', 'restricted_spectrum': '0, 1, 1, 16/9 x3'}

    # ---- families: inward, extremal upper, extremal lower
    t = sp.Symbol('t', positive=True); pstar = sp.log(T7, 2)
    inward = (16 - 9 * (2 - t) ** pstar) / 7
    assert sp.simplify(sp.diff(inward, t).subs(t, 0) - 8 * pstar / 7) == 0
    # upper family: all nine within-part edges shrink by h; eigenvalue derivative along it = 16p/7
    Hdir = {X[k]: (-1 if not (i < 3 <= j) else 0) for k, (i, j) in enumerate(EDGES)}
    assert sp.simplify(deriv.subs(Hdir).subs(p, pstar) - 16 * pstar / 7) == 0
    # lower family e0
    e0 = {x: 0 for x in X}
    for a_ in A_SET:
        e0[X[IDX[(a_, 3)]]] = R(-1, 4); e0[X[IDX[(a_, 4)]]] = R(-1, 4); e0[X[IDX[(a_, 5)]]] = R(1, 4); e0[X[IDX[(a_, 6)]]] = R(1, 4)
    e0[X[IDX[(3, 4)]]] = -1; e0[X[IDX[(5, 6)]]] = R(1, 2)
    assert sp.simplify(deriv.subs(e0).subs(p, pstar) - 2 * pstar / 21) == 0
    e0vec = sp.Matrix([e0[x] for x in X]); assert all(v >= 0 for v in D * e0vec) and sum(D * e0vec) == 3 and (w.T * e0vec)[0] == 0
    res['groups']['families'] = {'inward_derivative': '8p/7', 'upper_extremal_derivative': '16p/7', 'lower_extremal_derivative': '2p/21'}

    # ---- eigenvector inequality and two-simplex identity, compatibility factors
    u = sp.Symbol('u', nonnegative=True)
    assert sp.simplify(sp.factor((2 - u) ** 2 * (1 + u) - 4)) == sp.factor(u ** 2 * (u - 3))    # 2 - 2/sqrt(1+u) <= u for 0<=u<=3
    a, r, T = sp.symbols('a r T', positive=True)
    rhoA2 = (a - 1) / (2 * a); rhoB2 = T * (r - 1) / (2 * r); Fpat = (a + 1) * r / (a * (r - 1))
    assert sp.simplify((rhoA2 + rhoB2 - 1).subs(T, Fpat)) == 0
    assert sp.simplify(sp.solve(sp.Eq(rhoA2 + rhoB2, 1), T)[0] - Fpat) == 0
    n = sp.Symbol('n', positive=True)
    kn = lambda nn: ((nn - 1) * T - nn) / nn
    assert sp.simplify(kn(n) / (1 + kn(n)) - kn(n - 1) - (T - 1) * (n - (n - 2) * T) / (T * (n - 1))) == 0
    kk = sp.Symbol('k', positive=True)
    assert sp.simplify((kk + 1) / (kk - 1) - ((kk + 1) / kk) ** 2 - (kk + 1) / (kk ** 2 * (kk - 1))) == 0
    assert sp.simplify(kk / (kk - 2) - (kk + 1) / (kk - 1) - 2 / ((kk - 2) * (kk - 1))) == 0
    # converse correlation in lambda CS(a,2): 1 - aT/(a+1) = -kappa_a(T)
    assert sp.simplify(1 - a * T / (a + 1) + (a * T - a - 1) / (a + 1)) == 0
    assert (1 - a * T / (a + 1)).subs({a: 2, T: 2}) == R(-1, 3) and (1 - a * T / (a + 1)).subs({a: 3, T: T7}) == R(-1, 3)
    res['groups']['identities'] = {'eigenvector_inequality': 'checked', 'two_simplex': 'checked', 'compatibility_factor': 'checked',
                                   'strict_slack_differences': 'checked', 'converse_correlation': 'checked'}

    # ---- Taylor constants with exact arithmetic on the interval 0.83 <= p <= 0.8301, h <= 1/100
    plo, phi = R(83, 100), R(8301, 10000)
    assert sp.N(sp.log(T7, 2), 30) > plo and sp.N(sp.log(T7, 2), 30) < phi
    # p 2^{1-p} increasing on (0,1): derivative 2^{1-p}(1 - p ln 2) > 0
    assert sp.simplify(sp.diff(p * 2 ** (1 - p), p) - 2 ** (1 - p) * (1 - p * sp.log(2))) == 0
    # (1-h)^{p-2} <= (99/100)^{-(2-p)} <= (100/99)^{1.17} < 1.0119 for h<=1/100 and p>=0.83
    assert sp.N((R(100, 99)) ** R(117, 100), 30) < R(10119, 10000)
    q2 = R(1, 2) * phi * (1 - plo) * R(10119, 10000); assert q2 < R(715, 10000)
    assert 6 * q2 < R(429, 1000) and R(41, 7) * q2 < R(419, 1000)
    # sum_{i != j} |z_i z_j| = 41/7
    assert sum(abs(zstar[i] * zstar[j]) for i in range(7) for j in range(7) if i != j) == R(41, 7)
    # row sums of |p s^{p-1}| weights times |z_*|: 20/sqrt(84) on every row
    for i in range(7):
        assert sp.simplify(sum((R(8, 9) if (i >= 3 and j >= 3) else 1) * abs(zstar[j]) for j in range(7) if j != i) - 20 / sp.sqrt(84)) == 0
    assert sp.simplify(sp.sqrt(7) * 20 / sp.sqrt(84) - 10 / sp.sqrt(3)) == 0
    res['groups']['taylor_constants'] = {'q2_upper': '0.0715', 'H_minus_Hlin': '0.429 h^2', 'quadratic_form_error': '0.419 h^2', 'row_weight': '20/sqrt(84)'}
    (output / 'symbolic_results.json').write_text(json.dumps(res, indent=2, sort_keys=True) + '\n')
    print(json.dumps({'status': 'PASS', 'groups': len(res['groups']), 'output': str(output)}, indent=2))

if __name__ == '__main__':
    ap = argparse.ArgumentParser(description=__doc__); ap.add_argument('--output', type=Path, required=True)
    main(ap.parse_args().output)
