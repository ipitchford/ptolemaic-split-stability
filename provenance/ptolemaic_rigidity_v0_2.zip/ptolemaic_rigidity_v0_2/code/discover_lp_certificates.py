#!/usr/bin/env python3
"""How the dual certificates of Table 1 were found (provenance only; the verifiers do not use this).

Primal:  c* = min { 1^T D e : D e >= 0, w^T e = 0, ||e||_inf = 1 }  over the 42 choices of the
         edge attaining the sup-norm and its sign, solved numerically with HiGHS.
Dual:    for each choice, minimise the total weight on Ptolemy rows subject to
         D^T (1 - eta) = mu w + 3 sigma e_k, eta >= 0; then symmetrise under the stabiliser of the
         edge and solve the reduced linear system exactly with SymPy to obtain the one-parameter
         families whose points appear in Table 1.
Requires numpy, scipy and sympy.
"""
from __future__ import annotations
import argparse, json
from fractions import Fraction as F
from itertools import combinations, permutations
from pathlib import Path
import numpy as np, sympy as sp
from scipy.optimize import linprog

A_SET, B_SET = (0, 1, 2), (3, 4, 5, 6); M = 7
EDGES = list(combinations(range(M), 2)); IDX = {e: i for i, e in enumerate(EDGES)}
def row(terms):
    out = [0] * len(EDGES)
    for i, j, v in terms: out[IDX[tuple(sorted((i, j)))]] += v
    return out
ROWS = []; NAMES = []
for i in A_SET:
    for b, c in combinations(B_SET, 2):
        ROWS.append(row([(i, b, 1), (i, c, 1), (b, c, -1)])); NAMES.append(('tri', i, b, c))
for i, j in combinations(A_SET, 2):
    for b, c in combinations(B_SET, 2):
        ROWS.append(row([(i, b, 1), (i, c, 1), (j, b, 1), (j, c, 1), (i, j, -2), (b, c, -1)])); NAMES.append(('ptol', i, j, b, c))
D = np.array(ROWS, dtype=float); W = np.array([1.0 if i < 3 <= j else 0.0 for i, j in EDGES])
ONES = np.ones(len(ROWS)); CVEC = D.T @ ONES

def primal_values():
    out = {}
    for k, e in enumerate(EDGES):
        for sigma in (+1, -1):
            A_eq = np.vstack([W, np.eye(len(EDGES))[k] * sigma]); b_eq = np.array([0.0, 1.0])
            res = linprog(CVEC, A_ub=-D, b_ub=np.zeros(len(ROWS)), A_eq=A_eq, b_eq=b_eq, bounds=[(-1, 1)] * len(EDGES), method='highs')
            assert res.status == 0; out[f'{e}/{sigma:+d}'] = round(float(res.fun), 9)
    res = linprog(-CVEC, A_eq=W[None, :], b_eq=[0.0], bounds=[(-1, 1)] * len(EDGES), method='highs')
    return out, -float(res.fun)

def reduced_families():
    name_index = {n: i for i, n in enumerate(NAMES)}
    def relabel(n, pi):
        if n[0] == 'tri':
            b, c = sorted((pi[n[2]], pi[n[3]])); return ('tri', pi[n[1]], b, c)
        a1, a2 = sorted((pi[n[1]], pi[n[2]])); b, c = sorted((pi[n[3]], pi[n[4]])); return ('ptol', a1, a2, b, c)
    out = {}
    for edge in [(0, 1), (0, 3), (3, 4)]:
        G = [dict(zip(A_SET, pa)) | dict(zip(B_SET, pb)) for pa in permutations(A_SET) for pb in permutations(B_SET)]
        G = [pi for pi in G if tuple(sorted((pi[edge[0]], pi[edge[1]]))) == edge]
        orbit_of = {}; reps = []
        for n in NAMES:
            if n in orbit_of: continue
            orb = {relabel(n, pi) for pi in G}
            for o in orb: orbit_of[o] = len(reps)
            reps.append(n)
        for sigma in (+1, -1):
            Y = sp.symbols(f'eta0:{len(reps)}'); mu = sp.Symbol('mu'); k = IDX[edge]
            eta = sp.Matrix([Y[orbit_of[n]] for n in NAMES]); Dq = sp.Matrix(ROWS); wq = sp.Matrix([int(i < 3 <= j) for i, j in EDGES])
            eqs = list(Dq.T * (sp.ones(36, 1) - eta) - mu * wq - 3 * sigma * sp.Matrix([1 if t == k else 0 for t in range(21)]))
            (sol,) = list(sp.linsolve(eqs, list(Y) + [mu]))
            free = sorted(sol.free_symbols, key=str)
            rng = None
            if free:
                t = free[0]; rng = sp.Interval(-sp.oo, sp.oo)
                for r_i in range(len(reps)):
                    rng = rng.intersect(sp.solve_univariate_inequality(sol[r_i] >= 0, t, relational=False))
            out[f'{edge}/{sigma:+d}'] = {'orbit_representatives': [str(r) for r in reps], 'orbit_sizes': [sum(1 for n in NAMES if orbit_of[n] == i) for i in range(len(reps))],
                                          'family': [str(sol[i]) for i in range(len(reps))], 'mu': str(sol[-1]), 'free_parameter_range': str(rng)}
    return out

if __name__ == '__main__':
    ap = argparse.ArgumentParser(description=__doc__); ap.add_argument('--output', type=Path, required=True)
    args = ap.parse_args(); args.output.mkdir(parents=True, exist_ok=True)
    per_choice, cmax = primal_values()
    report = {'primal_minimum_over_42_choices': min(per_choice.values()), 'primal_values': per_choice, 'primal_maximum_box_only': cmax,
              'reduced_dual_families': reduced_families(), 'note': 'Provenance of Table 1; the verifiers check the displayed points exactly.'}
    assert abs(report['primal_minimum_over_42_choices'] - 3.0) < 1e-8 and abs(cmax - 72.0) < 1e-8
    (args.output / 'lp_discovery.json').write_text(json.dumps(report, indent=2, sort_keys=True) + '\n')
    print(json.dumps({'c_star': report['primal_minimum_over_42_choices'], 'c_max': cmax}, indent=2))
