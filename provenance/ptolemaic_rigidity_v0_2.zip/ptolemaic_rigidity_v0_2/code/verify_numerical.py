#!/usr/bin/env python3
"""Bounded numerical corroboration of the seven-point first-order law and linear stability, v0.2.

Random Ptolemaic perturbations of CS(3,4) with deviation h up to 1/100 are tested against the
two-sided law (8.9), the certificate bounds (8.12) and the linear bounds (8.14)-(8.15) of the note,
in the correct zero-sum subspace.  The two extremal families are followed to small h with
70-digit arithmetic.  Numerical tolerances are not exact positivity certificates; nothing here
proves the theorem.
"""
from __future__ import annotations
import argparse, itertools, json, math
from pathlib import Path
import numpy as np, mpmath as mp

A, R_, M = 3, 4, 7
P = math.log2(16 / 9)
EDGES = list(itertools.combinations(range(M), 2)); IDX = {e: i for i, e in enumerate(EDGES)}
S = np.array([2.0 if i >= A else 1.0 for i, j in EDGES])
W = np.array([1.0 if i < A <= j else 0.0 for i, j in EDGES])
Q, _ = np.linalg.qr(np.vstack([np.ones(M), np.eye(M)[: M - 1]]).T); Q = Q[:, 1:]
ZSTAR = np.array([4, 4, 4, -3, -3, -3, -3], dtype=float) / math.sqrt(84)

def mat(vec):
    D = np.zeros((M, M))
    for k, (i, j) in enumerate(EDGES): D[i, j] = D[j, i] = vec[k]
    return D
def gap_and_vector(vec):
    H = -Q.T @ (mat(vec) ** P) @ Q
    vals, vecs = np.linalg.eigh(H); z = Q @ vecs[:, 0]
    if z @ ZSTAR < 0: z = -z
    return vals[0], vals[1] - vals[0], z
def shrinkage(vec):
    return 12 * sum(1 - vec[IDX[e]] for e in EDGES if e[1] < A) + 6 * sum(2 - vec[IDX[e]] for e in EDGES if e[0] >= A)
def ptolemaic(vec):
    d = mat(vec)
    for i, j, k in itertools.combinations(range(M), 3):
        if d[i, j] > d[i, k] + d[k, j] or d[i, k] > d[i, j] + d[j, k] or d[j, k] > d[i, j] + d[i, k]: return False
    for i, j, k, l in itertools.combinations(range(M), 4):
        x = [d[i, j] * d[k, l], d[i, k] * d[j, l], d[i, l] * d[j, k]]
        if max(x) > sum(x) - max(x): return False
    return True
def active_rows():
    rows = []
    for i in range(A):
        for b, c in itertools.combinations(range(A, M), 2):
            r = np.zeros(len(EDGES)); r[IDX[(i, b)]] += 1; r[IDX[(i, c)]] += 1; r[IDX[(b, c)]] -= 1; rows.append(r)
    for i, j in itertools.combinations(range(A), 2):
        for b, c in itertools.combinations(range(A, M), 2):
            r = np.zeros(len(EDGES))
            for u in [(i, b), (i, c), (j, b), (j, c)]: r[IDX[u]] += 1
            r[IDX[(i, j)]] -= 2; r[IDX[(b, c)]] -= 1; rows.append(r)
    return np.array(rows)
E0 = np.zeros(len(EDGES))
for a_ in range(A):
    E0[IDX[(a_, 3)]] = E0[IDX[(a_, 4)]] = -0.25; E0[IDX[(a_, 5)]] = E0[IDX[(a_, 6)]] = 0.25
E0[IDX[(3, 4)]] = -1.0; E0[IDX[(5, 6)]] = 0.5
E1 = np.array([-1.0 if not (i < A <= j) else 0.0 for i, j in EDGES])

def mp_gap(vec, dps=70):
    mp.mp.dps = dps; p = mp.log(mp.mpf(16) / 9) / mp.log(2)
    d = mp.matrix(M, M)
    for k, (i, j) in enumerate(EDGES): d[i, j] = d[j, i] = mp.mpf(vec[k]) ** p
    Qm = mp.matrix(Q.tolist()); H = -(Qm.T * d * Qm)
    ev = mp.eigsy(H)[0]; return min(ev[i] for i in range(M - 1))

def main(output, seed, trials):
    output.mkdir(parents=True, exist_ok=True)
    rng = np.random.default_rng(seed); Dm = active_rows()
    res = {'status': 'PASS', 'version': '0.2', 'seed': seed, 'proof': False, 'groups': {}}
    c_law_lo, c_law_hi, c_lin_lo, c_lin_hi = 26.0, 0.5, 28.0, 0.5
    stats = {'attempted': 0, 'accepted': 0, 'rejected_not_ptolemaic': 0, 'failures': 0,
             'max_ratio_gap_over_h': 0.0, 'min_ratio_gap_over_h': np.inf, 'min_shrinkage_over_h': np.inf, 'max_shrinkage_over_h': 0.0,
             'max_defect_law_lower_over_h2': -np.inf, 'max_defect_law_upper_over_h2': -np.inf, 'max_eigvec_distance_over_h': 0.0}
    with open(output / 'numerical_trials.jsonl', 'w') as fh:
        for tr in range(trials):
            stats['attempted'] += 1
            h = 10 ** rng.uniform(-4, -2)
            e = rng.uniform(-1, 1, len(EDGES)); e[W > 0] -= e[W > 0].mean()
            delta = (Dm @ e).min()
            if delta < 0: e = e + (-delta + rng.uniform(0, 0.5)) * E1
            e *= h / np.abs(e).max(); vec = S + e
            if not ptolemaic(vec):
                stats['rejected_not_ptolemaic'] += 1; continue
            stats['accepted'] += 1
            hh = np.abs(e).max(); g, above, z = gap_and_vector(vec); L = shrinkage(vec)
            law_lo = (2 * P / 63) * L - c_law_lo * hh ** 2; law_hi = (2 * P / 63) * L + c_law_hi * hh ** 2
            checks = {'law': bool(law_lo - 1e-13 <= g <= law_hi + 1e-13),
                      'certificate': bool(3 * hh - 58.5 * hh ** 2 - 1e-13 <= L <= 72 * hh + 1e-13),
                      'linear': bool(2 * P / 21 * hh - c_lin_lo * hh ** 2 - 1e-13 <= g <= 16 * P / 7 * hh + c_lin_hi * hh ** 2 + 1e-13),
                      'clean': bool((hh > 1e-3) or (hh / 20 - 1e-14 <= g <= 2 * hh)),
                      'eigenvector': bool(np.linalg.norm(z - ZSTAR) <= 6 * hh + 1e-12), 'simple': bool(above > 0.5)}
            ok = all(checks.values())
            if not ok: stats['failures'] += 1; res['status'] = 'FAIL'
            stats['max_ratio_gap_over_h'] = max(stats['max_ratio_gap_over_h'], g / hh); stats['min_ratio_gap_over_h'] = min(stats['min_ratio_gap_over_h'], g / hh)
            stats['min_shrinkage_over_h'] = min(stats['min_shrinkage_over_h'], L / hh); stats['max_shrinkage_over_h'] = max(stats['max_shrinkage_over_h'], L / hh)
            stats['max_defect_law_lower_over_h2'] = max(stats['max_defect_law_lower_over_h2'], ((2 * P / 63) * L - g) / hh ** 2)
            stats['max_defect_law_upper_over_h2'] = max(stats['max_defect_law_upper_over_h2'], (g - (2 * P / 63) * L) / hh ** 2)
            stats['max_eigvec_distance_over_h'] = max(stats['max_eigvec_distance_over_h'], np.linalg.norm(z - ZSTAR) / hh)
            fh.write(json.dumps({'trial': tr, 'h': float(hh), 'gap': float(g), 'shrinkage': float(L), 'checks': checks, 'eigengap_above': float(above)}) + '\n')
    stats['sharp_constants'] = {'2p/21': 2 * P / 21, '16p/7': 16 * P / 7, '2p/63': 2 * P / 63}
    res['groups']['random_perturbations'] = stats
    # near-extremal sampler: relabelled copies of the extremal direction e0 plus small noise and a
    # small interior push; this probes the region where the lower constant is nearly attained
    near = {'attempted': 0, 'accepted': 0, 'failures': 0, 'min_ratio_gap_over_h': np.inf, 'max_ratio_gap_over_h': 0.0,
            'min_shrinkage_over_h': np.inf, 'max_defect_law_lower_over_h2': -np.inf}
    for tr in range(trials // 2):
        near['attempted'] += 1
        h = 10 ** rng.uniform(-4, -2); noise = rng.uniform(0.0, 0.3); push = rng.uniform(0.0, 0.2)
        pa = rng.permutation(A); pb = A + rng.permutation(R_); pi = {**{i: int(pa[i]) for i in range(A)}, **{A + i: int(pb[i]) for i in range(R_)}}
        e = np.zeros(len(EDGES))
        for k, (i, j) in enumerate(EDGES): e[IDX[tuple(sorted((pi[i], pi[j])))]] = E0[k]
        e = e + noise * rng.uniform(-1, 1, len(EDGES)); e[W > 0] -= e[W > 0].mean()
        delta = (Dm @ e).min()
        if delta < 0: e = e + (-delta + push) * E1
        e *= h / np.abs(e).max(); vec = S + e
        if not ptolemaic(vec): continue
        near['accepted'] += 1
        hh = np.abs(e).max(); g, above, z = gap_and_vector(vec); L = shrinkage(vec)
        ok = ((2 * P / 63) * L - c_law_lo * hh ** 2 - 1e-13 <= g <= (2 * P / 63) * L + c_law_hi * hh ** 2 + 1e-13
              and 3 * hh - 58.5 * hh ** 2 - 1e-13 <= L <= 72 * hh + 1e-13
              and 2 * P / 21 * hh - c_lin_lo * hh ** 2 - 1e-13 <= g <= 16 * P / 7 * hh + c_lin_hi * hh ** 2 + 1e-13
              and ((hh > 1e-3) or (hh / 20 - 1e-14 <= g <= 2 * hh)) and np.linalg.norm(z - ZSTAR) <= 6 * hh + 1e-12 and above > 0.5)
        if not ok: near['failures'] += 1; res['status'] = 'FAIL'
        near['min_ratio_gap_over_h'] = min(near['min_ratio_gap_over_h'], g / hh); near['max_ratio_gap_over_h'] = max(near['max_ratio_gap_over_h'], g / hh)
        near['min_shrinkage_over_h'] = min(near['min_shrinkage_over_h'], L / hh)
        near['max_defect_law_lower_over_h2'] = max(near['max_defect_law_lower_over_h2'], ((2 * P / 63) * L - g) / hh ** 2)
    res['groups']['near_extremal_perturbations'] = near
    fam = {'lower_family_e0': [], 'upper_family_e1': [], 'inward_family_v01': []}
    for j in range(4, 16):
        h = 2.0 ** -j
        v0 = S + h * E0 + h * h * E1; assert ptolemaic(v0)
        dev = np.abs(v0 - S).max(); g70 = float(mp_gap(v0)); fam['lower_family_e0'].append({'h': h, 'deviation': dev, 'gap_over_deviation': g70 / dev})
        v1 = S + h * E1; assert ptolemaic(v1); fam['upper_family_e1'].append({'h': h, 'gap_over_h': float(mp_gap(v1)) / h})
        v2 = S.copy(); v2[[IDX[e] for e in EDGES if e[0] >= A]] -= h; assert ptolemaic(v2)
        fam['inward_family_v01'].append({'h': h, 'gap_over_h': float(mp_gap(v2)) / h})
    # the ratios must approach the predicted limits monotonically in these ranges
    lo = [x['gap_over_deviation'] for x in fam['lower_family_e0']]; hi = [x['gap_over_h'] for x in fam['upper_family_e1']]
    assert abs(lo[-1] - 2 * P / 21) < 2e-4 and abs(hi[-1] - 16 * P / 7) < 2e-4 and abs(fam['inward_family_v01'][-1]['gap_over_h'] - 8 * P / 7) < 2e-4
    assert all(lo[i] >= lo[i + 1] for i in range(len(lo) - 1)) and all(hi[i] >= hi[i + 1] for i in range(len(hi) - 1))
    fam['limits'] = {'lower': 2 * P / 21, 'upper': 16 * P / 7, 'inward': 8 * P / 7, 'precision_digits': 70}
    res['groups']['extremal_families'] = fam
    (output / 'numerical_results.json').write_text(json.dumps(res, indent=2, sort_keys=True, default=float) + '\n')
    print(json.dumps({'status': res['status'], 'accepted': stats['accepted'], 'failures': stats['failures'],
                      'min_gap_over_h': stats['min_ratio_gap_over_h'], 'max_gap_over_h': stats['max_ratio_gap_over_h']}, indent=2, default=float))
    if res['status'] != 'PASS': raise SystemExit(1)

if __name__ == '__main__':
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--output', type=Path, required=True); ap.add_argument('--seed', type=int, default=20260927); ap.add_argument('--trials', type=int, default=4000)
    a = ap.parse_args(); main(a.output, a.seed, a.trials)
