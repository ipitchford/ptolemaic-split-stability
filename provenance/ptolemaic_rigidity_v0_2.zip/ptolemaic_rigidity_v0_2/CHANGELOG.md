# Changelog

## 0.2 — 27 September 2026

Review of version 0.1 (see `REVIEW_REPORT.md`) and development. No statement of version 0.1 was found to be false; the following were added or changed.

- **Attribution.** The coefficient transport of Lemma 5.1 is attributed to Ercan (2026, Theorem 8.1) and the sign-shift to his Theorem 8.2; Li–Weston (2010) is cited for strict descent and for the non-strictness of the supremal exponent; Kato (1995) for first-order eigenvalue perturbation.
- **Six points (new, Theorem 1.2, Section 6).** Equality metrics at $p_6=1$ are the similarities of $\mathrm{CS}(2,4)$ and $\mathrm{CS}(3,3)$, conditional on strict 1-negative type of Ptolemaic metrics on at most five points (which follows from the cited external results). Lemma 6.1 verifies the companion inputs at $p=1$, $n\le3$.
- **Geometry (new, Proposition 7.1, Remark 8.5).** Two regular simplices with a common centre for every binding split; the first-variation formula of the gap for every $m$.
- **Stability (strengthened, Section 8).** First-order law with explicit two-sided error; exact symmetrised dual certificates (Table 1) replacing the rational left inverse; sharp first-order constants $2p_*/21$ and $16p_*/7$ with attaining families; $h/20\le\Delta\le2h$ for $h\le1/1000$ (was $h/25\le\Delta\le6h$ for $h\le1/5000$); eigenvector bound $6h$ (was $18h$); global local constant $40$ (was $50$).
- **Statements.** Lemma 3.1, Corollary 3.2 and Lemma 4.1 restated more precisely; the unnumbered corollary of Section 5 is now Remark 5.2.
- **Code.** `verify_exact.py` checks the six certificates on all 42 edge–sign pairs, the primal extremal directions, the sharp families at dyadic $h$, the rational constant chain, the two-simplex identities, the $p=1$ inputs and parameter cases from $m=6$. `verify_symbolic.py` reconstructs $D$ from the inequalities, re-derives the certificate families, and checks the derivative, first-variation, spectral, Taylor and geometric identities. `verify_numerical.py` tests all displayed inequalities up to $h=1/100$ and follows the extremal families at 70 digits. New: `search_equality.py` (optimisation search for equality metrics, $m=6,7,8$) and `discover_lp_certificates.py` (provenance of Table 1).
- **Bundle.** `REVIEW_REPORT.md`, this changelog, updated ledgers and claim map; the v0.1 replay receipt and the input hashes are kept in `provenance/`. The LaTeX preamble falls back to `txfonts` when `newtx` is absent.

## 0.1 — 27 September 2026

First research draft: classification for $m\ge7$, seven-point local stability with constants $1/25$, $6$, radius $1/5000$, separated-class stability and the collision obstruction.
