# Review guide (version 0.2)

## Precise claims

1. Classify the positive, distinct-point Ptolemaic metrics with a nonzero endpoint equality vector at the companion threshold $p_m$, for every $m\ge7$ (Theorem 1.1), and for $m=6$ under the stated external strictness hypothesis (Theorem 1.2).
2. For seven points, with mean cross-distance one and entrywise deviation $h$ from $\mathrm{CS}(3,4)$: the first-order law $\Delta=\frac{2p_*}{63}\ell+O(h^2)$ with explicit two-sided error for $h\le1/100$ (Theorem 8.4); the certificate $3h-\frac{117}{2}h^2\le\ell\le72h$ with both constants sharp (Proposition 8.6); the linear bounds with sharp first-order constants and $h/20\le\Delta\le2h$ for $h\le1/1000$ (Theorem 8.7).
3. Separated-class stability with a non-explicit complement constant and the collision obstruction (Section 9).

## Imported premises

Companion v1.0: threshold theorem for $m\ge6$; Proposition 6.1 (sub-one strictness of smaller cardinalities); Theorem 3.4; Lemma 4.1; Lemma 4.4; Theorem 5.1; Corollary 5.2 and (5.9). External, for $m=6$ only: strict 1-negative type on at most five points (Ercan Thm 6.2; BHKL Thm 7.16 with Li–Weston). Ercan's Theorem 8.1 (transport) is reproved in Lemma 5.1.

## Scrutiny priorities

1. **Strict inverse slack (Lemma 3.1).** At an equality pair $\gamma=k_n$, the strict compatibility $k_{n-1}<k_n/(1+k_n)$ eliminates the opposite-sign and shared-negative incident cases. Check that the order-$(n-1)$ bound really applies to the deleted matrix (inversion closure) and that its parameter condition follows from (3.1). Equality in Cauchy–Schwarz forces constant root distances; row-sum equality in the star system forces $C=R$. No unproved classification of equality in the packing polytope is used.
2. **Return from the inverted star (Corollary 3.2).** The old infinity is a leaf; its star distance to every anchor fixes all original anchor–pole distances. Check the scale bookkeeping between raw and powered distances and the root independence of the pole correlation.
3. **Endpoint bookkeeping (Lemma 4.1).** Four nonnegative parts; the smaller-size inputs remain strict at the current endpoint; equality forces full support and the binding pattern; the full singular endpoint Gram matrix is never inverted.
4. **Balanced even case (Lemma 5.1, proof of Theorem 1.1).** $E_pz=\lambda\mathbf 1$ from the radical; $\lambda\ne0$ by inversion and smaller-support strictness; the inverted metric is an equality metric on $m$ points; the point $v$ with $z_v\lambda>0$ gives the adjacent pattern; the new infinity is in the larger class; inverting back returns the balanced type.
5. **The endpoint $p=1$ (Lemma 6.1, Theorem 1.2).** Check that the three inputs really are all that Lemma 3.1, Corollary 3.2 and Proposition 4.2 use from the companion for $n\le3$, and that the base case of the companion's Theorem 5.1 needs only $u,v\ge0$. Check that the six-point argument never needs $n=4$.
6. **First-order law (Lemmas 8.1–8.3, Theorem 8.4).** The derivative coefficient $2p_*/63$; the Taylor bound $q_2$ on the interval $0.83\le p_*\le0.8301$; the least-eigenvalue estimate with denominator $1-2\varepsilon$; the bound $|g|\le\frac{10p_*}{\sqrt3}h$ from the row weights $20/\sqrt{84}$; the arithmetic of $26$.
7. **Certificates (Proposition 8.6, Table 1).** Identity (8.11) for the six displayed certificates and their transport to all 42 edge–sign pairs; nonnegativity; Ptolemy weight $39/2$; the sign of $\eta^{\mathsf T}De$ (triangle slacks nonnegative, Ptolemy slacks at least $-3h^2$). Sharpness: $De_0\ge0$ with $\mathbf 1^{\mathsf T}De_0=3$; feasibility of $s+he_0+h^2e_1$ for $h\le1/20$, including the inactive constraints.
8. **Sharp linear stability (Theorem 8.7).** The insertion of (8.9) into (8.6); the numerical margins ($0.07904-0.028>1/20$ and $1.8974+0.0005<2$); the limit statements along the two families.
9. **Geometry (Proposition 7.1, Remark 8.5).** The circumradius identity and the extra axis; simplicity of the zero eigenvalue as the hypothesis of the first-variation formula.
10. **Global and collision limits.** The global constant is existential outside the explicit neighbourhood; distinct-point hypotheses and positive separation cannot be dropped.

## Assurance

The proofs have been derived, reviewed against the companion and the external sources, and checked in this workflow (see `REVIEW_REPORT.md`); they have not had independent specialist review. The three code implementations reconstruct algebraic certificates and corroborate numerically; they are not independent mathematical readers and not proof-assistant proofs. A reviewer should assess the analytic argument, not infer correctness from test counts.
