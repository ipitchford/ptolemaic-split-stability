# Review of research bundle v0.1 and record of the changes made in v0.2

**Reviewed object.** `ptolemaic_rigidity_v0_1.zip` (SHA-256 `aca64d88…8065`), research version 0.1 of *Rigidity at the sharp Ptolemaic negative-type threshold*, dated 27 September 2026, together with its companion `evidencepress_ptolemaic_v1_0.zip` (SHA-256 `2482a44b…23c4`).
**Review date.** 27 September 2026.
**Method.** The v0.1 replay was run in full mode with the nested companion replay (PASS: 32 manifested files, four jobs, nested five jobs over 130 files; receipt in `provenance/V01_REPLAY_REPORT.json`). Every statement of the v0.1 paper was then read against the companion manuscript, whose Theorems 3.4 and 5.1, Lemmas 4.1 and 4.4, Corollary 5.2 and Proposition 6.1 supply the premises, and against the two external preprints. Independent computations (exact rational, symbolic and floating point) were run for every finite object in the paper. The stability section was subjected to an exact linear-programming analysis of its own certificate. This is a producer-side review inside the same research workflow; it is not independent specialist refereeing.

## 1. Verdict on the mathematics of v0.1

**Classification (Theorem 1.1 of v0.1).** No logical gap was found. Each step was checked:

- Lemma 3.1 (strict inverse slack forces a star). The strict compatibility inequality $k_{n-1}<k_n/(1+k_n)$ is exactly what is needed to exclude both the opposite-sign and the shared-negative incident cases; the packing step forces $M=L_n$ and Cauchy–Schwarz equality forces equal root lengths; row-sum equality in the star system forces $C=R$. The parameter conditions requested from the companion (Theorem 5.1 at orders $n$ and $n-1$, Lemma 4.1) are those the companion states.
- Corollary 3.2. The return from the inverted star to the original metric is correct; the old infinity point is a leaf, which pins all anchor–pole distances.
- Lemma 4.1. The four-term decomposition (4.2) was re-derived; the integer solutions of $a(m-1-a)=D_m$ with $a\le m/2$ were verified for $6\le m\le300$ and by hand for general $m$.
- Proposition 4.2. The strict slack $T_m<(a+1)/(a-1)$ holds in exactly the unbalanced binding patterns; the gluing argument across pole pairs needs $a\ge2$ and $r\ge2$, both available.
- Lemma 5.1 and the balanced case. The transported vector is nonzero because the original one has full support; $\lambda\ne0$ follows from strictness on $m-1$ points; the sign pattern after inversion at a point of the sign of $\lambda$ is adjacent; the inversion formulas (5.2) were verified exactly for all vertex inversions with $6\le m\le18$.
- Converse and spectrum: verified exactly.

**Stability (Theorem 7.1 of v0.1).** The theorem is correct as stated, but its constants are far from sharp and the proof did not identify the first-order behaviour of the gap. An exact linear programme over the cone of linearised active constraints shows that the minimum of the shrinkage functional $\ell$ over $\|e\|_\infty=1$ is $3$, attained at a direction that shrinks one pole edge, lengthens another and moves cross-edges by a quarter; the left-inverse certificate of v0.1 only gives $9/4$. Combined with the exact derivative $z_*^{\mathsf T}H_{\rm lin}z_*=\frac{2p_*}{63}\ell$ (which v0.1 had) this gives the sharp first-order constants $2p_*/21\approx0.0791$ and $16p_*/7\approx1.897$ against v0.1's $1/25=0.04$ and $6$. The second-order constants of v0.1 ($75+24p_*/7$) came from a crude Taylor bound and a crude eigenvalue-perturbation bound; both were replaced, giving $26h^2$ and $28h^2$ and a radius of $1/1000$ instead of $1/5000$.

**Companion premises.** The statements used from the companion were read together with their proofs (packing theorem, inverse-correlation induction, cardinality induction). Their hypotheses match the uses made in v0.1 and v0.2. The companion's proofs were not re-derived independently in this review beyond that reading; the dependence on an unrefereed premise remains and is stated in the paper.

## 2. Findings, ranked

| # | Severity | Finding in v0.1 | Action in v0.2 |
|---|---|---|---|
| F1 | attribution | Lemma 5.1's transport formula is Ercan's Theorem 8.1 (quadratic-form covariance), and the sign-reversal mechanism is his Theorem 8.2; v0.1 cited Ercan only for the small cases. | Section 5 now opens by attributing the transport; the new content ($E_pz=\lambda\mathbf 1$ with $\lambda\ne0$ at an equality metric, and its use for classification) is isolated. Ercan's Theorem 6.2 (five-point equality system) and Proposition 4.3 (four-point Schur bound at $q=1$) are cited where relevant. |
| F2 | strength of result | Stability constants $1/25$, $6$, radius $1/5000$, eigenvector bound $18h$; no first-order law. | First-order law $\Delta=\frac{2p_*}{63}\ell+O(h^2)$ with explicit two-sided error (Theorem 8.4); exact dual certificates (Table 1) giving $3h-\frac{117}{2}h^2\le\ell\le72h$ (Proposition 8.6); sharp linear bounds $\frac{2p_*}{21}h-28h^2\le\Delta\le\frac{16p_*}{7}h+\frac12h^2$ and $h/20\le\Delta\le2h$ for $h\le1/1000$ (Theorem 8.7); eigenvector bound $6h$; both first-order constants shown attained. |
| F3 | scope | The six-point case ($p_6=1$) was excluded although the argument applies at $p=1$ with one external input. | Theorem 1.2 and Section 6: six-point equality metrics are $\mathrm{CS}(2,4)$ and $\mathrm{CS}(3,3)$, conditional on strict 1-negative type of Ptolemaic metrics on at most five points, which follows from Ercan (2026, Thm 6.2), Baker et al. (2026, Thm 7.16) and Li–Weston (2010). Lemma 6.1 records what survives of the companion's $0<p<1$ machinery at $p=1$, $n\le3$. |
| F4 | interpretation | The triangle–tetrahedron picture was given for seven points only. | Proposition 7.1: for every binding split the snowflake is two regular simplices in orthogonal subspaces with a common centre; $T=F(a,r)$ is exactly $\rho_A^2+\rho_B^2=1$; the equality vector is the coincidence of the two centres. Remark 8.5 gives the first-variation formula for every $m$. |
| F5 | precision | The closing remark of Section 5 asserted an equivalence between "supremal exponent equals $p_m$" and "equality metric" without the needed reference. | Remark 5.2 now cites Li–Weston's theorem that the supremal exponent of a finite metric space is never strict, which is exactly the missing direction. |
| F6 | precision | Lemma 3.1's conclusion referred to an "underlying metric" without defining it; Corollary 3.2 used a root-dependent Schur complement without noting root independence; Lemma 4.1's proof left the integer solution step and the vanishing of the second term implicit. | Statements and proofs rewritten accordingly; the companion equation used for root independence is cited as (5.9). |
| F7 | editorial | `RESEARCH_NOTE.md` contained "Corollary 7" (numbering glitch) and "are in ." (dropped path); an unnumbered corollary with a one-line proof was really a remark. | Regenerated from the source; the corollary is now Remark 5.2. |
| F8 | verification design | Numerical evidence for the classification consisted of seeded perturbations near inward split configurations; no search was made for unlisted equality metrics, in particular for a third eight-point type or an unlisted six-point type. | `code/search_equality.py`: local minimisation of the restricted gap over Ptolemaic metrics with distances in $[3/10,1]$ for $m=6,7,8$, 300 random starts each, comparing every near-zero minimiser with the predicted split copies up to relabelling and rescaling. All near-zero minimisers were split copies; both even types were found for $m=6$ and $m=8$; no small-gap point far from the splits occurred. Numerical corroboration only. |
| F9 | verification design | The v0.1 numerical script tested only $h\le1/5000$. | Random and near-extremal perturbation tests up to $h=1/100$ against every displayed inequality, with observed extreme ratios recorded; extremal families followed to $h=2^{-15}$ at 70 digits. |
| F10 | constants | v0.1's second-order Taylor bound $p(1-p)x^{p-2}\le1$ and eigenvalue bound $2\varepsilon^2$ were valid but wasteful. | Replaced by $q_2h^2$ with $q_2\le0.0715$ and by the Schur-complement bound $|b|^2/(1-2\varepsilon)$ with $|b|$ estimated through the structure of $H_{\rm lin}z_*$; every numerical constant is certified by a rational inequality chain in `verify_exact.py` and re-derived in `verify_symbolic.py`. |

No finding invalidates a v0.1 statement. Findings F2–F4 add results; F1 and F5 correct attribution and precision; the rest are presentation and verification design.

## 3. What this review did not do

- It did not formalise any statement in a proof assistant. The earlier quality-gate recommendation to formalise the two new lemmas (strict-slack equality and transport) in Lean stands.
- It did not compute an explicit global constant $C_\eta$ for the separated class; that requires a global lower bound on the gap away from the equality set and is left open.
- It did not classify equality for $m\le5$, where $p_m>1$ and the companion machinery does not apply; Ercan's Theorem 6.2 gives the five-point equality system but not its solution set.
- It did not re-derive the companion's proofs independently, and it did not perform an exhaustive priority search. The bounded source check found no published classification of the equality cases for any $m\ge6$.

## 4. Independent adversarial audit of the v0.2 draft

After the draft was complete, two separate readers with no access to this review's working notes were asked to break it: one on Sections 1–7 (classification, six points, transport, geometry) and one on Sections 8–9 (stability), each with instructions to report only verified problems, with demonstrations, classified as fatal, gap or minor. Both reported no fatal error and no gap after re-deriving the identities independently (symbolic and exact-rational checks of Lemma 3.1's chain, Corollary 3.2, the decomposition (4.2), the transport, the $p=1$ machinery at $n\le3$, Proposition 7.1, Lemmas 8.1–8.3, Theorem 8.4's constants, all six certificates, the sharp families on the whole interval $h\le1/20$, and Section 9). The minor findings were all accepted and fixed in the final v0.2 text:

| # | Finding | Fix |
|---|---|---|
| A1 | Lemma 6.1(ii) as first printed claimed an equal-arm star from $v>0$ and $M=n$ alone; the proof and the only use also need the Cauchy–Schwarz equality $UV=M^2$ (counterexample: root lengths $1,2,3$ with leaf distances $3,4,5$). | Hypothesis added to the statement. |
| A2 | Section 2 fixed $0<p\le1$ although the companion proves its Sections 3–5 for $0<p<1$; Lemma 3.1 and Corollary 3.2 carried no availability hypothesis. | Section 2 now fixes $0<p<1$; Lemma 3.1 and Corollary 3.2 state the required inputs and where they come from at $p=1$. |
| A3 | Lemma 6.1(iii) and the opening of Section 6 omitted the companion's inverse-block and inversion-closure lemmas from the inventory of inputs. | Added, with the remark that both are $p$-independent given $\mathsf S_1(4)$. |
| A4 | The derivation of the six-point hypothesis is more robust from Ercan's Theorem 6.1 with strict descent than from Theorem 6.2 alone. | Both routes cited. |
| A5 | The "∞" notation in Lemma 3.1 conflated the augmentation index with the point $\infty$ of the inverted metric. | Statement clarified. |
| A6 | "For the anchor edge the certificate is unique" is true only for symmetrised certificates; the LP with $\|e\|_\infty=1$ is not a single linear programme. | Rephrased: uniqueness of the symmetrised certificate; minimum over 42 linear programmes. |
| A7 | The bound for the quadratic Ptolemy terms of $d_h$ was looser than necessary, and the claim that inactive constraints "move by less than one half" had no argument. | Bound tightened to $2(h/4)^2+h^2(h+h^2)$; explicit movement bounds $0.16$ and $0.64$ given. |
| A8 | The limit along $d_h$ should be taken with the true deviation $h+h^2$. | Wording corrected. |

Both readers also noted that the eigenvector bound is stated as $6h$ where $5.33h$ is proved; it is not claimed sharp and was left as stated.
